
js

// api.js — Comunicação com o Web App (padrão do planner.js)
// URL definida no auth.js (const URL_API); fallback por segurança
const API_URL = (typeof URL_API !== 'undefined' && URL_API)
  ? URL_API
  : 'https://script.google.com/macros/s/AKfycbx1juNc0tIefpx0e-_xb4Vya00FkuIP8FnVsCySfdTdGyckSMQn3Cwr5YYtyhAyIbR6/exec';

// Chamada única: action + dados via POST form-data (code.gs lê e.parameter)
async function chamarApi(action, dados) {
  const fd = new FormData();
  fd.append('action', action);
  fd.append('dados', JSON.stringify(dados || {}));
  const resp = await fetch(API_URL, { method: 'POST', body: fd });
  return resp.json();
}

// Ações expostas para as páginas (o cronograma.js já chama api.getCronograma)
const api = {
  getCronograma: () => chamarApi('getCronograma'),
  getObras:      () => chamarApi('getObras'),
  getTarefas:    () => chamarApi('getTarefas'),
  getUsuarios:   () => chamarApi('getUsuarios')
};