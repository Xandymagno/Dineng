// =========================================================
// auth.js — Login, sessão e permissões (conectado ao code.gs)
// Regras:
// 1. Usuário COM senha na planilha -> valida o hash no servidor
// 2. Usuário SEM senha (bootstrap) -> a senha padrão 12345 é
//    convertida para vazio no navegador (nunca vai para a API) e
//    o sistema pede o cadastro de uma senha nova
// =========================================================

// URL do Web App do Apps Script (publicado a partir do code.gs)
const URL_API = 'https://script.google.com/macros/s/AKfycbx1juNc0tIefpx0e-_xb4Vya00FkuIP8FnVsCySfdTdGyckSMQn3Cwr5YYtyhAyIbR6/exec';

// ===== Chamada à API =====
async function chamarApi(action, dados) {
  const fd = new FormData();
  fd.append('action', action);
  fd.append('dados', JSON.stringify(dados || {}));
  const resp = await fetch(URL_API, { method: 'POST', body: fd });
  return resp.json();
}

// ===== Sessão =====
function salvarSessao(usuario) {
  sessionStorage.setItem('usuario', JSON.stringify(usuario));
}

function obterSessao() {
  const dados = sessionStorage.getItem('usuario');
  return dados ? JSON.parse(dados) : null;
}

// Protege páginas internas: sem sessão, volta pro login
function exigirLogin() {
  if (!obterSessao()) {
    window.location.href = '../index.html';
  }
}

function sair() {
  sessionStorage.removeItem('usuario');
  window.location.href = '../index.html';
}

// ===== Tela de login (index.html) =====
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('form-login');
  const formSenha = document.getElementById('form-definir-senha');

  if (form) {
    form.addEventListener('submit', async (evento) => {
      evento.preventDefault();

      const email = document.getElementById('usuario').value.trim();
      let senha = document.getElementById('senha').value;
      const erro = document.getElementById('login-erro');

      // Senha padrão 12345 vira vazia (modo bootstrap — validação é local)
      if (senha === '12345') senha = '';

      erro.classList.remove('visivel');

      try {
        const r = await chamarApi('login', { email: email, senha: senha });

        if (!r.success) {
          erro.textContent = r.erro || 'Usuário ou senha inválidos.';
          erro.classList.add('visivel');
          return;
        }

        salvarSessao(r.usuario);

        if (r.bootstrap) {
          // Usuário sem senha cadastrada: pede a definição de uma senha nova
          if (formSenha) {
            form.style.display = 'none';
            formSenha.style.display = 'block';
          } else {
            window.location.href = 'pages/dashboard.html';
          }
          return;
        }

        window.location.href = 'pages/dashboard.html';
      } catch (e) {
        erro.textContent = 'Erro de conexão com o servidor. Tente novamente.';
        erro.classList.add('visivel');
      }
    });
  }

  if (formSenha) {
    formSenha.addEventListener('submit', async (evento) => {
      evento.preventDefault();

      const erro = document.getElementById('senha-erro');
      const s1 = document.getElementById('nova-senha-login').value;
      const s2 = document.getElementById('confirmar-senha-login').value;

      erro.classList.remove('visivel');

      if (s1.length < 4) {
        erro.textContent = 'A senha deve ter pelo menos 4 caracteres.';
        erro.classList.add('visivel');
        return;
      }
      if (s1 !== s2) {
        erro.textContent = 'As senhas não conferem.';
        erro.classList.add('visivel');
        return;
      }

      const sessao = obterSessao();
      if (!sessao || !sessao.email) {
        window.location.href = 'index.html';
        return;
      }

      try {
        const r = await chamarApi('definirSenha', { email: sessao.email, senha: s1 });
        if (r.success) {
          window.location.href = 'pages/dashboard.html';
        } else {
          erro.textContent = r.erro || 'Não foi possível salvar a senha.';
          erro.classList.add('visivel');
        }
      } catch (e) {
        erro.textContent = 'Erro de conexão com o servidor. Tente novamente.';
        erro.classList.add('visivel');
      }
    });
  }
});
