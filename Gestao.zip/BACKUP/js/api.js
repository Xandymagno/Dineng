// =========================================================
// api.js — Camada de comunicação com o Google Apps Script
// Mesmo padrão do planner.js: FormData + POST para a URL_API
// =========================================================

// URL definida no auth.js (const URL_API); fallback por segurança
const API_URL = (typeof URL_API !== 'undefined' && URL_API)
  ? URL_API
  : 'https://script.google.com/macros/s/AKfycbx1juNc0tIefpx0e-_xb4Vya00FkuIP8FnVsCySfdTdGyckSMQn3Cwr5YYtyhAyIbR6/exec';

const api = (function () {
  // Chamada única: action + dados via POST form-data (code.gs lê e.parameter)
  async function chamarApi(action, dados) {
    const fd = new FormData();
    fd.append('action', action);
    fd.append('dados', JSON.stringify(dados || {}));
    const resp = await fetch(API_URL, { method: 'POST', body: fd });
    return resp.json();
  }

  return {
    chamarApi: chamarApi,
    getCronograma: function () { return chamarApi('getCronograma'); },
    getObras: function () { return chamarApi('getObras'); },
    getTarefas: function () { return chamarApi('getTarefas'); },
    getUsuarios: function () { return chamarApi('getUsuarios'); }
  };
})();
