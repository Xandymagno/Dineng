# Gestão de Obras — Dashboard

Sistema web em HTML, CSS e JavaScript puro, com dados no Google Sheets via Apps Script.

## Estrutura

- `index.html` — tela de login
- `css/` — estilos (fonts, style, sidebar, login)
- `js/` — lógica (api, auth, sidebar, app, charts + uma por página)
- `pages/` — dashboard, obras, planner, cronograma, usuarios
- `assets/` — logo, ícones e fontes

## Backend

O `code.gs` fica no editor do Apps Script vinculado à planilha — não é hospedado aqui.

## Segurança

- Nenhuma credencial no front-end
- Toda leitura/escrita passa pelo Apps Script (proxy)
- A planilha não é compartilhada publicamente
