// =========================================================
// code.gs — API do Dashboard Gestão de Obras (DINENG)
// Conecta o front-end (HTML/JS) à planilha "Gerenciamento_backup"
// Todas as leituras/escritas passam por este Web App
// =========================================================

// ===== CONFIGURAÇÃO =====
const ID_PLANILHA = '1je_OyWg-aXQ6mo212dk-V-3rcXtCa3TuSeeQdW4Ish0';
const ABA = {
  GERAL: 'Geral',
  RELATORIO: 'Relatorio',
  OBS_GERAL: 'Obs_Geral',
  TAREFAS: 'Tarefas',
  OBS_TAREFA: 'Obs_Tarefa',
  USUARIOS: 'Usuários',
  STATUS_GERAL: 'status_geral',
  STATUS_TAREFAS: 'status_tarefas',
  STATUS_FINANCEIRO: 'status_finaceiro',
  TIPO_PROPOSTA: 'TIPO_PROPOSTA',
  HISTORICO: 'historico_status_geral',
  CRONOGRAMA: 'Cronograma'
};

// =========================================================
// ROTEADOR — recebe action + dados e devolve JSON
// =========================================================
function doGet(e) { return rotear(e); }
function doPost(e) { return rotear(e); }
function rotear(e) {
  let resposta;
  try {
    const action = e.parameter.action || '';
    const dados = e.parameter.dados ? JSON.parse(e.parameter.dados) : {};
    switch (action) {
      // ----- Autenticação -----
      case 'login':            resposta = login(dados); break;
      case 'definirSenha':     resposta = definirSenha(dados); break;

      // ----- Obras (aba Geral) -----
      case 'getObras':         resposta = getObras(); break;
      case 'salvarObra':       resposta = salvarObra(dados); break;
      case 'excluirObra':      resposta = excluirObra(dados); break;

      // ----- Status e listas -----
      case 'getStatusGeral':   resposta = getStatusGeral(); break;
      case 'getStatusTarefas': resposta = getStatusTarefas(); break;
      case 'getStatusFinanceiro': resposta = getStatusFinanceiro(); break;
      case 'getTiposProposta': resposta = getTiposProposta(); break;

      // ----- Avanço de status + histórico -----
      case 'avancarStatus':    resposta = avancarStatus(dados); break;
      case 'getHistorico':     resposta = getHistorico(dados); break;

      // ----- Tarefas (aba Tarefas) -----
      case 'getTarefas':       resposta = getTarefas(); break;
      case 'salvarTarefa':     resposta = salvarTarefa(dados); break;
      case 'excluirTarefa':    resposta = excluirTarefa(dados); break;

      // ----- Cronograma -----
      case 'getCronograma':    resposta = getCronograma(); break;
      case 'salvarCronograma': resposta = salvarCronograma(dados); break;

      // ----- Observações -----
      case 'getObsGeral':      resposta = getObs('Obs_Geral', 'id_geral', dados.id_geral); break;
      case 'salvarObsGeral':   resposta = salvarObs('Obs_Geral', 'id_geral', dados); break;
      case 'getObsTarefa':     resposta = getObs('Obs_Tarefa', 'id_tarefa', dados.id_tarefa); break;
      case 'salvarObsTarefa':  resposta = salvarObs('Obs_Tarefa', 'id_tarefa', dados); break;

      // ----- Usuários -----
      case 'getUsuarios':            resposta = getUsuarios(); break;
      case 'salvarUsuario':          resposta = salvarUsuario(dados); break;
      case 'definirSituacaoUsuario': resposta = definirSituacaoUsuario(dados); break;

      // ----- Relatório -----
      case 'getRelatorio':     resposta = getRelatorio(); break;

      default:
        resposta = { success: false, erro: 'Ação desconhecida: ' + action };
    }
  } catch (erro) {
    resposta = { success: false, erro: String(erro) };
  }
  return ContentService
    .createTextOutput(JSON.stringify(resposta))
    .setMimeType(ContentService.MimeType.JSON);
}

// =========================================================
// HELPERS — leitura genérica de abas como objetos
// =========================================================
/** Lê uma aba inteira e devolve array de objetos (cabeçalho = chaves) */
function lerAba(nomeAba) {
  const aba = SpreadsheetApp.openById(ID_PLANILHA).getSheetByName(nomeAba);
  if (!aba) throw new Error('Aba não encontrada: ' + nomeAba);
  const valores = aba.getDataRange().getValues();
  if (valores.length < 2) return [];
  const cabecalhos = valores[0].map(function (h) { return String(h).trim(); });
  const linhas = [];
  for (let i = 1; i < valores.length; i++) {
    if (valores[i].join('') === '') continue; // pula linhas vazias
    const obj = { _linha: i + 1 };
    cabecalhos.forEach(function (cab, col) {
      obj[cab] = valores[i][col];
    });
    linhas.push(obj);
  }
  return linhas;
}

/** Gera um id curto único (8 caracteres) */
function gerarId() {
  return Utilities.getUuid().substring(0, 8);
}

/** Data/hora atual no formato da planilha */
function agora() {
  return Utilities.formatDate(new Date(), 'America/Sao_Paulo', 'dd/MM/yyyy HH:mm:ss');
}

/** Data atual (só dia) */
function hoje() {
  return Utilities.formatDate(new Date(), 'America/Sao_Paulo', 'dd/MM/yyyy');
}

// =========================================================
// SENHA — hash SHA-256 com sal (o e-mail é o sal)
// A planilha guarda SOMENTE o hash, nunca a senha pura
// A senha padrão (12345) é validada NO NAVEGADOR — nunca
// chega à API nem à planilha
// =========================================================
/** Gera o hash da senha (sal = e-mail do usuário, em minúsculas) */
function hashSenha(senha, email) {
  const bruto = String(email || '').trim().toLowerCase() + ':' + String(senha || '');
  const bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, bruto, Utilities.Charset.UTF_8);
  return bytes.map(function (b) {
    const hex = (b & 0xFF).toString(16);
    return hex.length === 1 ? '0' + hex : hex;
  }).join('');
}

/**
 * Define a senha de um usuário (grava o hash na coluna Senha).
 * Se a senha vier vazia, limpa o hash (usuário volta à rota sem senha).
 */
function definirSenha(dados) {
  const ss = SpreadsheetApp.openById(ID_PLANILHA);
  const aba = ss.getSheetByName(ABA.USUARIOS);
  const cabecalhos = aba.getRange(1, 1, 1, aba.getLastColumn()).getValues()[0];
  const colEmail = cabecalhos.indexOf('Email') + 1;
  const colSenha = cabecalhos.indexOf('Senha') + 1;
  if (!colEmail || !colSenha) {
    return { success: false, erro: 'Colunas Email/Senha não encontradas na aba Usuários' };
  }
  const emails = aba.getRange(2, colEmail, aba.getLastRow() - 1, 1).getValues();
  const alvo = String(dados.email || '').trim().toLowerCase();
  for (let i = 0; i < emails.length; i++) {
    if (String(emails[i][0]).trim().toLowerCase() === alvo) {
      const hash = dados.senha ? hashSenha(dados.senha, alvo) : '';
      aba.getRange(i + 2, colSenha).setValue(hash);
      return { success: true, mensagem: dados.senha ? 'Senha definida' : 'Senha removida' };
    }
  }
  return { success: false, erro: 'Usuário não encontrado' };
}

// =========================================================
// AUTENTICAÇÃO (aba Usuários)
// Regras:
// 1. Usuário COM senha na planilha -> valida o hash da senha enviada
// 2. Usuário SEM senha na planilha -> entra com senha VAZIA
//    (a validação da senha padrão 12345 é feita no navegador;
//     a senha padrão NUNCA chega à API)
// =========================================================
function login(dados) {
  const usuarios = lerAba(ABA.USUARIOS);
  const email = String(dados.email || '').trim().toLowerCase();
  const senha = String(dados.senha || '');
  const usuario = usuarios.find(function (u) {
    return String(u['Email'] || '').trim().toLowerCase() === email
        && String(u['Situaçao'] || '').toUpperCase() === 'ATIVO';
  });
  if (!usuario) return { success: false, erro: 'Usuário não encontrado ou inativo' };
  const hashSalvo = String(usuario['Senha'] || '').trim();
  // SEM senha cadastrada: entra com senha vazia (rota do navegador)
  if (hashSalvo === '') {
    if (senha !== '') {
      return { success: false, erro: 'Senha incorreta' };
    }
    return montarSessao(usuario, true);
  }
  // COM senha cadastrada: valida o hash
  if (hashSenha(senha, email) !== hashSalvo) {
    return { success: false, erro: 'Senha incorreta' };
  }
  return montarSessao(usuario, false);
}

/** Monta a resposta de sessão a partir da linha do usuário */
function montarSessao(usuario, bootstrap) {
  return {
    success: true,
    bootstrap: bootstrap,
    usuario: {
      id: String(usuario['ID_Usuário']),
      nome: usuario['Nome'],
      email: usuario['Email'],
      cargo: usuario['Cargo'],
      departamento: usuario['Departamento']
    }
  };
}

// =========================================================
// OBRAS (aba Geral)
// =========================================================
function getObras() {
  const obras = lerAba(ABA.GERAL).map(function (o) {
    return {
      id: String(o['id']),
      cod: String(o['cod'] || ''),
      interessado: o['Interessado'] || '',
      endereco: o['End'] || '',
      responsavel: o['Responsavel'] || '',
      telefone: String(o['Telefone'] || ''),
      tipo_proposta: o['TIPO PROPOSTA'] || '',
      responsavel_dineng: o['Responsavel_Dineng'] || '',
      cadastro: o['Cadastro'] || '',
      data_solicitacao: o['Data Solicitacao'] || '',
      status: o['Status'] || '',
      data_envio: o['Data Envio'] || '',
      data_novo_status: o['data_novo_status'] || '',
      status_anterior: o['Status Anterior'] || '',
      aparelho: o['aparelho'] || ''
    };
  });
  return { success: true, obras: obras };
}

function salvarObra(dados) {
  const ss = SpreadsheetApp.openById(ID_PLANILHA);
  const aba = ss.getSheetByName(ABA.GERAL);
  const cabecalhos = aba.getRange(1, 1, 1, aba.getLastColumn()).getValues()[0];
  let id = dados.id;
  let linhaExistente = 0;
  if (id) {
    const ids = aba.getRange(2, 1, aba.getLastRow() - 1, 1).getValues();
    for (let i = 0; i < ids.length; i++) {
      if (String(ids[i][0]) === String(id)) { linhaExistente = i + 2; break; }
    }
  } else {
    id = gerarId();
    const total = aba.getLastRow() - 1;
    dados.cod = String(total + 1);
    dados.cadastro = hoje();
  }
  const linha = cabecalhos.map(function (cab) {
    switch (cab) {
      case 'id': return id;
      case 'cod': return dados.cod || '';
      case 'Interessado': return dados.interessado || '';
      case 'End': return dados.endereco || '';
      case 'Responsavel': return dados.responsavel || '';
      case 'Telefone': return dados.telefone || '';
      case 'TIPO PROPOSTA': return dados.tipo_proposta || '';
      case 'Responsavel_Dineng': return dados.responsavel_dineng || '';
      case 'Cadastro': return dados.cadastro || '';
      case 'Data Solicitacao': return dados.data_solicitacao || '';
      case 'Status': return dados.status || 'CADASTRADA';
      case 'Data Envio': return dados.data_envio || '';
      case 'data_novo_status': return dados.data_novo_status || '';
      case 'Status Anterior': return dados.status_anterior || '';
      case 'aparelho': return dados.aparelho || '';
      default: return '';
    }
  });
  if (linhaExistente) {
    aba.getRange(linhaExistente, 1, 1, linha.length).setValues([linha]);
  } else {
    aba.appendRow(linha);
  }
  return { success: true, id: id };
}

function excluirObra(dados) {
  const ss = SpreadsheetApp.openById(ID_PLANILHA);
  const aba = ss.getSheetByName(ABA.GERAL);
  const ids = aba.getRange(2, 1, aba.getLastRow() - 1, 1).getValues();
  for (let i = 0; i < ids.length; i++) {
    if (String(ids[i][0]) === String(dados.id)) {
      aba.deleteRow(i + 2);
      return { success: true };
    }
  }
  return { success: false, erro: 'Obra não encontrada' };
}

// =========================================================
// STATUS E LISTAS (abas de apoio)
// =========================================================
function getStatusGeral() {
  const lista = lerAba(ABA.STATUS_GERAL)
    .map(function (s) {
      return { nome: s['NOME'], prazo: Number(s['PRAZO'] || 0), sequencia: Number(s['SEGUENCIA'] || 0) };
    })
    .sort(function (a, b) { return a.sequencia - b.sequencia; });
  return { success: true, status: lista };
}

function getStatusTarefas() {
  const lista = lerAba(ABA.STATUS_TAREFAS).map(function (s) {
    return { id: String(s['id']), nome: s['nome'] };
  });
  return { success: true, status: lista };
}

function getStatusFinanceiro() {
  const lista = lerAba(ABA.STATUS_FINANCEIRO).map(function (s) { return s['NOME']; });
  return { success: true, status: lista };
}

function getTiposProposta() {
  const lista = lerAba(ABA.TIPO_PROPOSTA).map(function (s) { return s['NOME']; });
  return { success: true, tipos: lista };
}

// =========================================================
// AVANÇO DE STATUS + HISTÓRICO
// =========================================================
function avancarStatus(dados) {
  const ss = SpreadsheetApp.openById(ID_PLANILHA);
  const aba = ss.getSheetByName(ABA.GERAL);
  const obras = lerAba(ABA.GERAL);
  const obra = obras.find(function (o) { return String(o['id']) === String(dados.id_obra); });
  if (!obra) return { success: false, erro: 'Obra não encontrada' };
  const statusAnterior = obra['Status'] || '';
  const novoStatus = dados.novo_status;
  const cabecalhos = aba.getRange(1, 1, 1, aba.getLastColumn()).getValues()[0];
  const colStatus = cabecalhos.indexOf('Status') + 1;
  const colDataNovo = cabecalhos.indexOf('data_novo_status') + 1;
  const colStatusAnt = cabecalhos.indexOf('Status Anterior') + 1;
  aba.getRange(obra._linha, colStatus).setValue(novoStatus);
  aba.getRange(obra._linha, colDataNovo).setValue(agora());
  aba.getRange(obra._linha, colStatusAnt).setValue(statusAnterior);
  const abaHist = ss.getSheetByName(ABA.HISTORICO);
  abaHist.appendRow([gerarId(), String(dados.id_obra), statusAnterior, novoStatus, agora(), dados.responsavel || '']);
  return { success: true, status_anterior: statusAnterior, novo_status: novoStatus };
}

function getHistorico(dados) {
  const lista = lerAba(ABA.HISTORICO)
    .filter(function (h) { return String(h['id_geral']) === String(dados.id_obra); })
    .map(function (h) {
      return {
        status_anterior: h['status_anterior'] || '',
        status_novo: h['status_novo'] || '',
        data: h['data'] || '',
        responsavel: h['responsavel'] || ''
      };
    });
  return { success: true, historico: lista };
}

// =========================================================
// TAREFAS (aba Tarefas)
// =========================================================
function getTarefas() {
  const tarefas = lerAba(ABA.TAREFAS).map(function (t) {
    return {
      id: String(t['ID_Tarefa']),
      id_projeto: String(t['ID_Projeto'] || ''),
      nome: t['Nome'] || '',
      descricao: t['Descrição'] || '',
      prioridade: t['Prioridade'] || '',
      data_vencimento: t['Data_Vencimento'] || '',
      status: t['Status'] || '',
      id_responsavel: String(t['ID_Responsável'] || ''),
      esforco: t['Esforço_Estimado (Dias)'] || '',
      previsao_inicio: t['Previsão Inicio'] || '',
      data_inicio: t['Data_Inicio'] || '',
      data_conclusao: t['Data_Conclusão'] || '',
      data_criacao: t['Data_criação'] || '',
      observacao: t['observação'] || ''
    };
  });
  return { success: true, tarefas: tarefas };
}

function salvarTarefa(dados) {
  const ss = SpreadsheetApp.openById(ID_PLANILHA);
  const aba = ss.getSheetByName(ABA.TAREFAS);
  const cabecalhos = aba.getRange(1, 1, 1, aba.getLastColumn()).getValues()[0];
  let id = dados.id;
  let linhaExistente = 0;
  if (id) {
    const colId = cabecalhos.indexOf('ID_Tarefa') + 1;
    const ids = aba.getRange(2, colId, aba.getLastRow() - 1, 1).getValues();
    for (let i = 0; i < ids.length; i++) {
      if (String(ids[i][0]) === String(id)) { linhaExistente = i + 2; break; }
    }
  } else {
    id = gerarId();
    dados.data_criacao = agora();
  }
  const linha = cabecalhos.map(function (cab) {
    switch (cab) {
      case 'ID_Tarefa': return id;
      case 'ID_Projeto': return dados.id_projeto || '';
      case 'Nome': return dados.nome || '';
      case 'Descrição': return dados.descricao || '';
      case 'Prioridade': return dados.prioridade || 'Média';
      case 'Data_Vencimento': return dados.data_vencimento || '';
      case 'Status': return dados.status || 'A fazer';
      case 'ID_Responsável': return dados.id_responsavel || '';
      case 'Esforço_Estimado (Dias)': return dados.esforco || '';
      case 'Previsão Inicio': return dados.previsao_inicio || '';
      case 'Data_Inicio': return dados.data_inicio || '';
      case 'Data_Conclusão': return dados.data_conclusao || '';
      case 'Data_criação': return dados.data_criacao || '';
      case 'observação': return dados.observacao || '';
      default: return '';
    }
  });
  if (linhaExistente) {
    aba.getRange(linhaExistente, 1, 1, linha.length).setValues([linha]);
  } else {
    aba.appendRow(linha);
  }
  return { success: true, id: id };
}

function excluirTarefa(dados) {
  const ss = SpreadsheetApp.openById(ID_PLANILHA);
  const aba = ss.getSheetByName(ABA.TAREFAS);
  const ids = aba.getRange(2, 1, aba.getLastRow() - 1, 1).getValues();
  for (let i = 0; i < ids.length; i++) {
    if (String(ids[i][0]) === String(dados.id)) {
      aba.deleteRow(i + 2);
      return { success: true };
    }
  }
  return { success: false, erro: 'Tarefa não encontrada' };
}

// =========================================================
// CRONOGRAMA (aba Cronograma)
// =========================================================
function getCronograma() {
  const tarefas = lerAba(ABA.CRONOGRAMA)
    .filter(function (c) {
      // Pula linhas sem nome ou sem datas válidas (lixo/teste)
      const nome = String(c['Tarefa'] || '').trim();
      const inicio = converterDataISO(c['Início']);
      const fim = converterDataISO(c['Fim']);
      return nome !== '' && inicio !== '' && fim !== '';
    })
    .map(function (c) {
      return {
        id: String(c['ID_Cronograma']),
        id_obra: String(c['ID_Obra'] || ''),
        obra: c['Obra'] || '',
        id_tarefa: String(c['ID_Tarefa'] || ''),
        name: c['Tarefa'] || '',
        start: converterDataISO(c['Início']),
        end: converterDataISO(c['Fim']),
        progress: Number(converterPercentual(c['% Concluído'])) || 0,
        responsavel: c['Responsável'] || '',
        predecessor: c['Predecessora'] || ''
      };
    });
  return { success: true, tarefas: tarefas };
}

/** Converte dd/MM/yyyy para yyyy-MM-dd (formato do front-end) */
function converterDataISO(valor) {
  if (!valor) return '';
  // Célula com formato de data → objeto Date (converte direto)
  if (valor instanceof Date) {
    const pad = function (n) { return ('0' + n).slice(-2); };
    return valor.getFullYear() + '-' + pad(valor.getMonth() + 1) + '-' + pad(valor.getDate());
  }
  const texto = String(valor).trim();
  // dd/MM/yyyy -> yyyy-MM-dd
  const br = texto.match(/^(\d{2})\/(\d{2})\/(\d{4})/);
  if (br) return br[3] + '-' + br[2] + '-' + br[1];
  // Já vem em ISO yyyy-MM-dd
  const iso = texto.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (iso) return iso[1] + '-' + iso[2] + '-' + iso[3];
  return '';
}


/** Converte "100%" ou 1 para número 0-100 */
function converterPercentual(valor) {
  if (valor === null || valor === undefined || valor === '') return 0;
  const numero = parseFloat(String(valor).replace('%', '').replace(',', '.'));
  if (isNaN(numero)) return 0;
  return numero <= 1 ? Math.round(numero * 100) : Math.round(numero);
}

/**
 * Sincroniza uma tarefa do Planner na aba Cronograma.
 * Cria a linha se a tarefa ainda não existe ou atualiza a linha
 * existente, preservando a % de evolução lançada manualmente.
 * O front-end envia { id_tarefa, id_obra, obra, tarefa, inicio,
 * fim, responsavel, predecessor, percentual }.
 */
function salvarCronograma(dados) {
  const ss = SpreadsheetApp.openById(ID_PLANILHA);
  const aba = ss.getSheetByName(ABA.CRONOGRAMA);
  if (!aba) return { success: false, erro: 'Aba Cronograma não encontrada' };
  const cabecalhos = aba.getRange(1, 1, 1, aba.getLastColumn()).getValues()[0];

  function indiceColuna(nome) {
    for (let i = 0; i < cabecalhos.length; i++) {
      if (String(cabecalhos[i]).trim().toLowerCase() === String(nome).toLowerCase()) return i;
    }
    return -1;
  }

  const colIdTarefa = indiceColuna('ID_Tarefa');
  let colPct = -1;
  for (let i = 0; i < cabecalhos.length; i++) {
    const h = String(cabecalhos[i]);
    if (h.indexOf('%') !== -1 && h.toLowerCase().indexOf('conclu') !== -1) { colPct = i; break; }
  }

  let linhaExistente = 0;
  if (colIdTarefa >= 0 && dados.id_tarefa) {
    const vals = aba.getRange(2, colIdTarefa + 1, Math.max(aba.getLastRow() - 1, 1), 1).getValues();
    for (let i = 0; i < vals.length; i++) {
      if (String(vals[i][0]) === String(dados.id_tarefa)) { linhaExistente = i + 2; break; }
    }
  }

  // Preserva a % existente se o front não enviar percentual
  const existentes = linhaExistente ? aba.getRange(linhaExistente, 1, 1, cabecalhos.length).getValues()[0] : null;
  const percentual = (dados.percentual !== undefined && dados.percentual !== null)
    ? Number(dados.percentual)
    : (colPct >= 0 && existentes ? existentes[colPct] : 0);

  const linha = cabecalhos.map(function (cab, col) {
    const c = String(cab).trim().toLowerCase();
    if (c === 'id_cronograma') return linhaExistente ? existentes[col] : gerarId();
    if (c === 'id_obra' || c === 'id_projeto') return dados.id_obra || '';
    if (c === 'obra') return dados.obra || '';
    if (c === 'id_tarefa') return dados.id_tarefa || '';
    if (c === 'tarefa') return dados.tarefa || '';
    if (c === 'inicio' || c === 'início' || c === 'data_inicio') return dados.inicio || '';
    if (c === 'fim' || c === 'data_fim') return dados.fim || '';
    if (c.indexOf('%') !== -1 && c.indexOf('conclu') !== -1) return percentual;
    if (c === 'responsavel' || c === 'responsável') return dados.responsavel || '';
    if (c === 'predecessora') return dados.predecessora || '';
    return linhaExistente ? existentes[col] : '';
  });

  if (linhaExistente) {
    aba.getRange(linhaExistente, 1, 1, linha.length).setValues([linha]);
  } else {
    aba.appendRow(linha);
  }
  return { success: true, id: dados.id_tarefa || '' };
}

// =========================================================
// OBSERVAÇÕES (abas Obs_Geral e Obs_Tarefa)
// =========================================================
function getObs(nomeAba, campoChave, valorChave) {
  const lista = lerAba(nomeAba)
    .filter(function (o) { return String(o[campoChave]) === String(valorChave); })
    .map(function (o) {
      return { id: String(o['id']), data: o['data'] || '', observacao: o['Observação'] || '' };
    });
  return { success: true, observacoes: lista };
}

function salvarObs(nomeAba, campoChave, dados) {
  const aba = SpreadsheetApp.openById(ID_PLANILHA).getSheetByName(nomeAba);
  aba.appendRow([gerarId(), String(dados[campoChave] || ''), agora(), dados.observacao || '']);
  return { success: true };
}

// =========================================================
// USUÁRIOS (aba Usuários)
// A coluna Senha NUNCA é devolvida ao front-end
// =========================================================
function getUsuarios() {
  const usuarios = lerAba(ABA.USUARIOS).map(function (u) {
    return {
      id: String(u['ID_Usuário']),
      nome: u['Nome'] || '',
      email: u['Email'] || '',
      cargo: u['Cargo'] || '',
      departamento: u['Departamento'] || '',
      situacao: u['Situaçao'] || '',
      data_cadastro: u['data_cadastro'] || '',
      telefone: String(u['telefone'] || ''),
      tem_senha: String(u['Senha'] || '').trim() !== ''
    };
  });
  return { success: true, usuarios: usuarios };
}

function salvarUsuario(dados) {
  const ss = SpreadsheetApp.openById(ID_PLANILHA);
  const aba = ss.getSheetByName(ABA.USUARIOS);
  const cabecalhos = aba.getRange(1, 1, 1, aba.getLastColumn()).getValues()[0];
  let id = dados.id;
  let linhaExistente = 0;
  if (id) {
    const ids = aba.getRange(2, 1, aba.getLastRow() - 1, 1).getValues();
    for (let i = 0; i < ids.length; i++) {
      if (String(ids[i][0]) === String(id)) { linhaExistente = i + 2; break; }
    }
  } else {
    id = String(aba.getLastRow()); // próximo número sequencial
    dados.data_cadastro = agora();
  }
  // Ao editar SEM senha nova, preserva o hash existente
  const colSenha = cabecalhos.indexOf('Senha');
  const valoresExistentes = linhaExistente
    ? aba.getRange(linhaExistente, 1, 1, cabecalhos.length).getValues()[0]
    : null;
  const linha = cabecalhos.map(function (cab, col) {
    switch (cab) {
      case 'ID_Usuário': return id;
      case 'Nome': return dados.nome || '';
      case 'Email': return dados.email || '';
      case 'Cargo': return dados.cargo || '';
      case 'Departamento': return dados.departamento || '';
      case 'Situaçao': return dados.situacao || 'ATIVO';
      case 'data_cadastro': return dados.data_cadastro || '';
      case 'data_desativado': return dados.data_desativado || '';
      case 'telefone': return dados.telefone || '';
      case 'Senha':
        if (dados.senha) return hashSenha(dados.senha, String(dados.email || '').trim().toLowerCase());
        if (valoresExistentes) return valoresExistentes[colSenha]; // preserva hash atual
        return '';
      default: return '';
    }
  });
  if (linhaExistente) {
    aba.getRange(linhaExistente, 1, 1, linha.length).setValues([linha]);
  } else {
    aba.appendRow(linha);
  }
  return { success: true, id: id };
}

/** Ativa ou desativa um usuário sem apagar os dados (Situaçao + data_desativado) */
function definirSituacaoUsuario(dados) {
  const ss = SpreadsheetApp.openById(ID_PLANILHA);
  const aba = ss.getSheetByName(ABA.USUARIOS);
  const cabecalhos = aba.getRange(1, 1, 1, aba.getLastColumn()).getValues()[0];
  const colSituacao = cabecalhos.indexOf('Situaçao') + 1;
  const colDesativado = cabecalhos.indexOf('data_desativado') + 1;
  const ids = aba.getRange(2, 1, aba.getLastRow() - 1, 1).getValues();
  for (let i = 0; i < ids.length; i++) {
    if (String(ids[i][0]) === String(dados.id)) {
      aba.getRange(i + 2, colSituacao).setValue(dados.situacao || 'ATIVO');
      aba.getRange(i + 2, colDesativado).setValue(
        String(dados.situacao || '').toUpperCase() === 'INATIVO' ? agora() : ''
      );
      return { success: true };
    }
  }
  return { success: false, erro: 'Usuário não encontrado' };
}

// =========================================================
// RELATÓRIO (aba Relatorio — somente leitura)
// =========================================================
function getRelatorio() {
  const linhas = lerAba(ABA.RELATORIO).map(function (r) {
    return {
      interessado: r['Interessado'] || '',
      etapa: r['Nome (Status)'] || '',
      descricao: r['Descrição'] || '',
      status_tarefa: r['Status (Tarefa)'] || '',
      responsavel: r['Responsável'] || '',
      telefone: String(r['Telefone'] || ''),
      email: r['E-mail'] || '',
      vencimento: r['Vencimento'] || ''
    };
  });
  return { success: true, relatorio: linhas };
}