-- ============================================================
--  Banco: gerenciamento.db  (DINENG - Gestão de Obras)
--  Origem: planilha Google Sheets "Gerenciamento" (12 abas)
--  Correções: datas em ISO 8601, e-mail validado, senha hasheada
--  Como usar:  sqlite3 gerenciamento.db < gerenciamento.sql
-- ============================================================

PRAGMA foreign_keys = ON;

BEGIN TRANSACTION;

-- ------------------------------------------------------------
-- 1. USUÁRIOS  (aba Usuários)
--    - email: validado com CHECK
--    - senha_hash: obriga formato de hash (64 hex = SHA-256)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS usuarios (
    id_usuario      TEXT PRIMARY KEY,
    nome            TEXT NOT NULL,
    email           TEXT CHECK (email IS NULL OR email = '' OR email LIKE '%_@_%._%'),
    cargo           TEXT,
    departamento    TEXT,
    situacao        TEXT,
    data_cadastro   DATETIME,
    data_desativado DATETIME,
    telefone        TEXT,
    senha_hash      TEXT CHECK (senha_hash IS NULL OR (length(senha_hash) = 64 AND senha_hash GLOB '[0-9a-fA-F]*'))
);

INSERT INTO usuarios (id_usuario, nome, email, cargo, departamento, situacao, data_cadastro, data_desativado, telefone, senha_hash) VALUES
('1',    'Alexandre Magno', 'alexandre@dineng.com.br', 'Coordenador',    'Gestão',        'ATIVO', NULL,                 NULL, '63999548837', 'ee10bcc91eae84f063cde0e2174d1c2f667bc32a42845d939187ccc94a552a2c'),
('2',    'Victor Emmanuel', NULL,                      'Gerente',        'Gestão',        'ATIVO', '2026-04-29 18:44:47', NULL, NULL,         NULL),
('1000', 'Energisa',        NULL,                      'Concessionária', 'Concessionária','ATIVO', '2014-01-01',           NULL, NULL,         NULL),
('4',    'Siron',           'siron@dineng.com.br',     'Diretor',        'Gestão',        'ATIVO', '2026-08-03 14:41:44', NULL, NULL,         NULL),
('5',    'Alexandre Teste', 'alexandre@123.com',       'Gerente',        'Gestao',        'ATIVO', '2026-10-04 15:32:26', NULL, NULL,         '2d7e7e93ac70716fbc6bb29a9f2767c897b967bb0720a98e6f29cc4d09c7a0fa');

-- ------------------------------------------------------------
-- 2. STATUS GERAIS  (aba status_geral)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS status_geral (
    nome      TEXT PRIMARY KEY,
    prazo     INTEGER,
    sequencia INTEGER
);

INSERT INTO status_geral (nome, prazo, sequencia) VALUES
('CADASTRADA',               2, 0),
('ELABORAÇÃO DA PROPOSTA',   4, 1),
('PROPOSTA ENVIADA',         8, 2),
('CANCELADO',                0, 3),
('ANALISE ENERGISA',         5, 5),
('CONTRATO EM ANDAMENTO', NULL, 3),
('CONTRATO ENCERRADO',       0, 4),
('AGUARDANDO PAGAMENTO',     5, 5);

-- ------------------------------------------------------------
-- 3. STATUS DE TAREFAS  (aba status_tarefas)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS status_tarefas (
    id   INTEGER PRIMARY KEY,
    nome TEXT NOT NULL
);

INSERT INTO status_tarefas (id, nome) VALUES
(1, 'Levantamento de Campo'),
(2, 'Elaboração de Projeto'),
(3, 'Projeto em Analise'),
(4, 'Cotação/Aquisição de Materiais'),
(5, 'Execução da Obra'),
(6, 'Solicitação de Comissionamento'),
(7, 'Analise de Comissionamento'),
(8, 'Elaboração de Proposta');

-- ------------------------------------------------------------
-- 4. STATUS FINANCEIRO  (aba status_finaceiro)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS status_financeiro (
    nome TEXT PRIMARY KEY
);

INSERT INTO status_financeiro (nome) VALUES
('ACEITAÇÃO PROP. PAGO'),
('PENDENTE PG. INIC. PROJ.'),
('PENDENTE.PG. APROV. PROJ.'),
('PENDENTE. PG. INIC. OBRA'),
('PENDENTE. PG. CONC. OBRA'),
('PENDENTE. PG. APROV. OBRA'),
('INIC. PROJ. PAGO'),
('APROV. PROJ. PAGO'),
('INICIO OBRA PAGO'),
('CONC. EXEC. OBRA PAGO'),
('APROV. OBRA PAGO');

-- ------------------------------------------------------------
-- 5. TIPOS DE PROPOSTA  (aba TIPO_PROPOSTA)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tipo_proposta (
    nome TEXT PRIMARY KEY
);

INSERT INTO tipo_proposta (nome) VALUES
('PROJ. EXT. REDE + TRAFO'),
('PROJ. EXT. REDE + SUBESTAÇÃO'),
('PROJ. EXT. RDR MT'),
('PROJ. EXT. RDU MT'),
('PROJ. EXT. RDR BT'),
('PROJ. EXT. RDU BT'),
('PROJ. SUBESTAÇÃO'),
('PROJ. TRAFO'),
('EXEC. SUBESTAÇÃO'),
('EXEC. TRAFO'),
('EXEC. RELIGADOR'),
('EXEC. EXT. REDE + TRAFO'),
('EXEC. EXT. REDE + SUBESTAÇÃO'),
('EXEC. EXT. RDR MT'),
('EXEC. EXT. RDU MT'),
('EXEC. EXT. RDR BT'),
('EXEC. EXT. RDU BT'),
('PROJ. E EXEC. EXT. REDE + TRAFO'),
('PROJ. E EXEC. REDE + SUBESTAÇÃO'),
('PROJ. E EXEC. RDR MT'),
('PROJ. E EXEC. RDU MT'),
('PROJ. E EXEC. RDR BT'),
('PROJ. E EXEC. RDU BT'),
('SERVIÇOS DE LINHA VIVA'),
('PROJ E EXEC. TRIFASEAMENTO + TRAFO'),
('LINHA VIVA S/LINHA MORTA'),
('LINHA VIVA C/LINHA MORTA'),
('REGULADOR DE TENSÃO'),
('CONFECÇÃO MALHA ATERRAMENTO'),
('EXEC. DESLOC. REDE MT '),
('FISCALIZAÇÃO DE OBRAS'),
('MDA');

-- ------------------------------------------------------------
-- 6. OBRAS  (aba Geral)
--    - datas em ISO 8601
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS obras (
    id                 TEXT PRIMARY KEY,
    cod                INTEGER,
    interessado        TEXT,
    endereco           TEXT,
    responsavel        TEXT,
    telefone           TEXT,
    tipo_proposta      TEXT,
    responsavel_dineng TEXT,
    cadastro           DATE,
    data_solicitacao   DATE,
    status             TEXT,
    data_envio         DATETIME,
    data_novo_status   DATETIME,
    status_anterior    TEXT,
    caminho            TEXT
);

INSERT INTO obras (id, cod, interessado, endereco, responsavel, telefone, tipo_proposta, responsavel_dineng, cadastro, data_solicitacao, status, data_envio, data_novo_status, status_anterior, caminho) VALUES
('1',          1,  'Soares Barros Engenharia LTDA', '', 'Longuimar Soares Barros', '6384013675', 'PROJETO DE SUBESTAÇÃO ELEVADORA DE 6MVA', '2', '2026-01-01', NULL, 'CONTRATO EM ANDAMENTO', NULL, '2026-05-26 11:40:50', 'PROPOSTA ENVIADA', NULL),
('2',          2,  'LODI GERAÇÃO DE ENERGIA ELETRICA LTDA', '', 'ADEMIR', '6392135852', 'PROJETO E CONSTRUÇÃO DE UMA SUBESTAÇÃO DE MEDIÇÃO E PROTEÇÃO MT DE 1500KVA', '2', '2026-01-01', NULL, 'CONTRATO ENCERRADO', NULL, '2026-10-04 15:56:54', 'CONTRATO ENCERRADO', NULL),
('3',          3,  'LODI GERAÇÃO DE ENERGIA ELETRICA LTDA', '', 'ADEMIR', '6392135852', 'PROJETO E CONSTRUÇÃO DE UMA SUBESTAÇÃO DE MEDIÇÃO E PROTEÇÃO MT DE 500KVA', '2', '2026-01-01', NULL, 'CONTRATO ENCERRADO', NULL, '2026-10-04 15:57:06', 'CONTRATO EM ANDAMENTO', NULL),
('4',          4,  'TABOCA SANTA ROSA', '', NULL, NULL, 'PROJETO E CONSTRUÇÃO DE 39M DE REDE E 01 TRAFO DE 150KVA', '2', '2026-01-01', NULL, 'CANCELADO', NULL, '2026-05-25 16:51:54', 'PROPOSTA ENVIADA', NULL),
('5',          5,  'TABOCA SÃO VALERIO', '', NULL, NULL, 'PROJETO E CONSTRUÇÃO DE 180M DE REDE E 01 TRAFO DE 150KVA', '2', '2026-01-01', NULL, 'CANCELADO', NULL, '2026-05-26 10:03:30', 'PROPOSTA ENVIADA', NULL),
('6',          6,  'TABOCA JAU', '', NULL, NULL, 'PROJETO E CONSTRUÇÃO DE 117M DE REDE E 01 TRAFO DE 75KVA', '2', '2026-01-01', NULL, 'CANCELADO', NULL, '2026-05-26 10:03:57', 'PROPOSTA ENVIADA', NULL),
('7',          7,  'UNIÃO NACIONAL POR MORADIA POPULAR NO ESTADO DO TOCANTINS', '', 'KAREN CARVALHO', '6384510844', 'PROJETO DE LOTAMENTO ', '2', '2026-01-01', NULL, 'PROPOSTA ENVIADA', NULL, NULL, NULL, NULL),
('8',          8,  'LUCIANO VLADARES (DISBRAVA)', '', 'JOÃO GABRIEL', '6392292110', 'PROJETO DE EXTENSÃO DE REDE COM 01 TRANSFORMADOR DE 75KVA', '2', '2026-01-01', NULL, 'CANCELADO', NULL, '2026-05-26 11:39:54', 'PROPOSTA ENVIADA', NULL),
('9',          9,  'FARO ENERGY', '', 'Camila Oliveira', '11917666109', 'SUBSTITUIÇÃO DE 72 METROS DE CABOS SUBTERRANEOS', '2', '2026-01-01', NULL, 'CANCELADO', NULL, '2026-05-26 11:39:05', 'PROPOSTA ENVIADA', NULL),
('10',         10, 'OPY', '', 'GABRIEL', '6496626810', 'CONSTRUÇÃO DE UMA SUBESTAÇÃO DE MEDIÇÃO MT COM 01 TRANSFORMADOR DE 225KVA-13,8KV', '2', '2026-01-01', NULL, 'CANCELADO', NULL, NULL, NULL, NULL),
('11',         11, 'OPY', '', 'GABRIEL', '6496626810', 'CONSTRUÇÃO DE 01 TRANSFORMADOR DE 225KVA-13,8KV', '2', '2026-01-01', NULL, 'CONTRATO EM ANDAMENTO', NULL, NULL, NULL, NULL),
('12',         12, 'BRK', '', 'PAULO MARCIO', '6384662524', 'INSTALAÇÃO DE UM DISJUNTOR MT 34,5KV EM SUBESTAÇÃO EXISTENTE', '2', '2026-01-01', NULL, 'CANCELADO', NULL, '2026-05-26 11:38:24', 'PROPOSTA ENVIADA', NULL),
('13',         13, 'BP BIOENENG', 'Pedro Afonso', 'Kelly Ribeiro', NULL, 'CONSTRUÇÃO DE 30KM DE RDR 13,8KV E INSTALAÇÃO DE 6 SE DE 500 A 2000KVA', '2', '2026-01-01', NULL, 'CANCELADO', NULL, '2026-05-26 11:37:07', 'PROPOSTA ENVIADA', NULL),
('14',         14, 'Hochschild ', 'Serra Alta Mineradora', 'Ray Machado', '6392141639  ', 'CONSTRUÇÃO DE 2 SE DE MEDIÇÃO E PROTEÇÃO COM CONST DE 1,7KM E INSTALAÇÃO DE 1 TRAFO DE 75KVA', '1', '2026-01-01', NULL, 'CONTRATO EM ANDAMENTO', NULL, NULL, NULL, NULL),
('15',         15, 'BP BIOENENG', 'Pedro Afonso', 'Kelly Riveiro', NULL, 'PROJETO DE MEDIÇÃO E PROTEÇÃO PARA LIGAR O CAPEX 25_751', '1', '2026-01-01', NULL, 'CANCELADO', NULL, '2026-05-26 11:37:20', 'PROPOSTA ENVIADA', NULL),
('16',         16, 'ANDRE SIMONASSI', '', 'ANDRE SIMONASSI', '6399345088', 'CONSTRUÇÃO DE 01 POSTO DE TRANSFORMAÇÃO DE 150KVA', '2', '2026-01-01', NULL, 'PROPOSTA ENVIADA', NULL, NULL, NULL, NULL),
('f7a18331',   17, 'VIP EMPREENDIMENTO', 'ALVORORADA', 'GUILHERME', '63984020758', 'PROJETO DE MEDIÇÃO AGRUPADA', '1', '2026-04-08', NULL, 'CONTRATO EM ANDAMENTO', NULL, NULL, NULL, NULL),
('15baa0e0',   18, 'JORGE PELIZON', '', 'BRUNO DELEON PERCI', '62984316408', 'PROJETO E CONSTRUÇÃO DE REDE E SUBESTAÇÃO DE REDE DE MÉDIA TENSÃO 500kVA', '2', '2026-04-30', NULL, 'CONTRATO EM ANDAMENTO', NULL, '2026-05-26 11:40:36', 'PROPOSTA ENVIADA', NULL),
('719fac09',   21, 'ROMULO LUIZ MAMEDIO E OUTROS', 'LOTE 165 do loteamento CORREGO PRATA Nº 0', 'ALENCAR', NULL, 'PROJETO E EXECUÇÃO DE LOTEAMENTO RURAL MONO DE 19,9KV', '2', NULL, NULL, 'PROPOSTA ENVIADA', '2026-06-01 17:24:20', '2026-05-29 08:18:44', 'ELABORAÇÃO DA PROPOSTA', NULL),
('5886bcd6',   19, 'Hochschild', '', 'RONALDO PIMENTEL', '27 99994-1324', 'PROJETO DE UMA SUBESTAÇÃO DE MEDIÇÃO, PROTEÇÃO E TRANSFORMAÇÃO', '2', NULL, NULL, 'CONTRATO EM ANDAMENTO', '2026-06-01 17:25:08', '2026-07-03 09:50:08', 'PROPOSTA ENVIADA', NULL),
('c77a872d',   20, 'ADRIANO RISTAU', '', 'ADRIANO RISTAU', '47 9955-2875', 'PROJETO DE ADEQUAÇÃO DA SE E EXTENSÃO DE RDR BT SUBTERRANEA', '2', NULL, NULL, 'PROPOSTA ENVIADA', '2026-06-01 17:25:50', NULL, 'ELABORAÇÃO DA PROPOSTA', NULL),
('178567a2',   22, 'BRUNO DELEON', 'DIVINOPOLIS', 'BRUNO DELEON', NULL, 'SE DE 225KVA', '1', NULL, NULL, 'PROPOSTA ENVIADA', '2026-07-03 09:50:16', '2026-06-23 18:58:18', 'ELABORAÇÃO DA PROPOSTA', NULL),
('278ea05b',   24, 'BANCO DO BRASIL', 'TOCANTINOPOLIS', 'GIOVANA', '6381475078', 'ADEQUAÇÃO DO POSTO DE TRANSFORMAÇÃO - TRAFO DE 112,5KVA', '1', NULL, NULL, 'CANCELADO', '2026-07-29 08:56:50', '2026-07-29 08:56:51', 'PROPOSTA ENVIADA', NULL),
('7bff53de',   23, 'Renato Neponuceno', 'Quartel da Policia Militar do Tocantins', 'Renato Neponuceno', '61 9376-5733', 'DIAGNOSTICO FALHA RELIGADOR', '2', NULL, NULL, 'PROPOSTA ENVIADA', NULL, NULL, NULL, NULL),
('c9a9c1d2',   25, 'BRASOL SOLUCOES ENERGETICAS LTDA', 'MIRACEMA-TO', 'RAFAEL MARCONDES', '11917468079', 'ENSAIOS DE TRANSFORMADOR E AJUSTES DE PROTEÇÃO RELÉ', '2', NULL, NULL, 'PROPOSTA ENVIADA', NULL, NULL, NULL, '19e3b191-0e5e-4b7b-9f9e-07dcd5b9eac8'),
('9bbe9738',   26, 'FAZENDÃO AGRONEGÓCIO', 'POLO INDUSTRIAL LUZIMANGUES', NULL, NULL, 'PROJETOS', '1', NULL, NULL, 'PROPOSTA ENVIADA', '2026-08-03 08:56:33', '2026-07-29 08:56:45', 'ELABORAÇÃO DA PROPOSTA', '3ca130df-53ec-4703-a212-7811ce30d9cb'),
('487bc5a8',   27, 'TTS', 'MIRACEMA', 'LUCAS CORREA', '11912860403', 'MANUTENÇÃO SE - BRASOL', '2', NULL, NULL, 'CONTRATO EM ANDAMENTO', '2026-08-03 08:57:44', '2026-08-05 10:11:22', 'PROPOSTA ENVIADA', '3ca130df-53ec-4703-a212-7811ce30d9cb'),
('6e7b0650',   28, 'HOCHSHILD', 'FAZENDA MONTE DO CARMO', 'RONALDO PIMENTEL', NULL, 'ADITIVO', '1', NULL, NULL, 'PROPOSTA ENVIADA', '2026-08-21 10:26:58', '2026-08-21 10:26:56', 'ELABORAÇÃO DA PROPOSTA', '3ca130df-53ec-4703-a212-7811ce30d9cb'),
('d554d20e',   29, 'LEANDRO ALVES MARTINS', 'NOVO JARDIM', 'ALAN JOSE', NULL, 'CONSTRUÇÃO DE 12,03KM DE RDR MT 19,9KV E UM TRANSFORMADOR DE 25KVA', '1', NULL, NULL, 'CONTRATO EM ANDAMENTO', '2026-08-28 11:26:34', '2026-08-28 11:26:35', 'PROPOSTA ENVIADA', '3ca130df-53ec-4703-a212-7811ce30d9cb'),
('a15afa4e',   30, 'UNIÃO NACIONAL POR MORADIA POPULAR DO ESTADO DO TOCANTINS', 'BOM JESUS DO TOCANTINS-TO', 'VICTOR', '63984495557', 'EXECUÇÃO DE LOTEAMENTO', '2', NULL, NULL, 'PROPOSTA ENVIADA', '2026-09-24 14:39:11', NULL, 'ELABORAÇÃO DA PROPOSTA', '84b4aa31-463d-4800-9f40-c794f2e4ce38'),
('b96c353a',   31, 'Teste', '', NULL, NULL, 'teste', NULL, '2026-10-04', NULL, 'CONTRATO EM ANDAMENTO', NULL, '2026-10-04 16:24:07', 'PROPOSTA ENVIADA', NULL);

-- ------------------------------------------------------------
-- 7. TAREFAS  (aba Tarefas)
--    - datas em ISO 8601
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tarefas (
    id_tarefa           TEXT PRIMARY KEY,
    id_projeto          TEXT,
    nome                TEXT,
    descricao           TEXT,
    prioridade          TEXT,
    data_vencimento     DATE,
    status              TEXT,
    id_responsavel      TEXT,
    esforco_estimado_dias INTEGER,
    previsao_inicio     DATE,
    data_inicio         DATETIME,
    data_conclusao      DATETIME,
    data_criacao        DATETIME,
    observacao          TEXT,
    FOREIGN KEY (id_projeto) REFERENCES obras(id)
);

INSERT INTO tarefas (id_tarefa, id_projeto, nome, descricao, prioridade, data_vencimento, status, id_responsavel, esforco_estimado_dias, previsao_inicio, data_inicio, data_conclusao, data_criacao, observacao) VALUES
('a26dd08a', '14', '2', 'Rede interna', 'Alta', '2026-04-29', 'Concluído', '1', 1, '2026-04-20', '2026-04-29', '2026-05-26 12:03:53', '2026-04-29 17:33:42', NULL),
('ec473d97', '14', '1', 'Coletar resistividade', 'Alta', '2026-05-05', 'Concluído', '1', 3, '2026-04-21', '2026-05-12 12:02:36', '2026-05-12 18:02:39', '2026-04-29 18:54:04', NULL),
('d138a3c9', '14', '4', 'Comprar materiais', 'Média', '2026-05-08', 'Concluído', '2', 5, '2026-04-01', '2026-05-01', '2026-06-01 17:31:54', '2026-04-29 18:54:43', NULL),
('7bb75203', '14', '5', 'Execução da SE', 'Alta', '2026-06-08', 'Em Andamento', '1', 7, '2026-06-02', '2026-08-13 08:21:57', NULL, '2026-04-29 18:55:48', NULL),
('c8965f7c', '14', '5', 'Execução da rede Interna', 'Média', '2026-04-29', 'Em Andamento', '2', 7, '2026-06-02', '2026-08-13 08:22:09', NULL, '2026-04-29 18:56:09', NULL),
('cf817b0f', '11', '2', 'Projeto de posto de transformação de 225KVA', 'Baixa', '2026-04-08', 'Concluído', '1', 1, '2026-04-06', '2026-04-08 00:00:00', '2026-04-08 11:44:17', '2026-04-30 09:59:09', NULL),
('09efb314', '11', '3', 'Analise do projeto com apoio do Governo', 'Alta', '2026-05-17', 'Concluído', '1000', 5, '2026-04-17', '2026-04-17 00:00:00', '2026-05-17 11:50:12', '2026-04-30 10:11:51', NULL),
('3825840e', '2',  '2', 'Malha de aterramento', 'Média', '2026-05-05', 'Concluído', '1', 1, '2026-05-04', '2026-05-04', '2026-05-04 17:06:18', '2026-05-04 09:02:32', NULL),
('1f843fa3', '3',  '2', 'Malha de aterramento', 'Média', '2026-05-05', 'Concluído', '1', 2, '2026-05-04', '2026-05-04 17:06:48', '2026-05-04 17:06:49', '2026-05-04 09:03:05', NULL),
('0fc03a3d', '2',  '2', 'Projeto construtivo', 'Baixa', '2026-05-04', 'Concluído', '2', 5, NULL, '2026-08-13 08:19:25', '2026-08-13 08:19:26', '2026-05-04 17:04:29', NULL),
('20690850', '2',  '2', 'Proteção e seletividade', 'Baixa', '2026-05-04', 'Concluído', '2', 2, NULL, '2026-08-13 08:19:31', '2026-08-13 08:19:36', '2026-05-04 17:05:15', NULL),
('3e94b2ec', '14', '6', 'Comissionar rede', 'Alta', '2026-07-07', 'Em Andamento', '2', 30, '2026-06-08', '2026-08-13 08:22:00', NULL, '2026-05-05 09:55:28', NULL),
('f0f0b954', '14', '2', 'Seletividade e proteção', 'Alta', '2026-05-04', 'Concluído', '2', 2, '2026-04-27', '2026-05-26 12:05:00', '2026-05-26 12:05:01', '2026-05-05 09:58:54', NULL),
('7bcff0e6', '15baa0e0', '2', 'PROJETO SUBESTAÇÃO 500KVA', 'Alta', '2026-06-03', 'Em Andamento', '2', 3, '2026-06-01', '2026-06-01 17:29:41', NULL, '2026-06-01 17:27:59', '2026-01-06 17:29:54Entrou em Analise'),
('89be8c5a', '7bff53de', '8', '1.1. PRESTAÇÃO DE SERVIÇOS DE ANÁLISE TÉCNICA E DIAGNÓSTICO DE ATUAÇÃO DE RELIGADOR DE MÉDIA TENSÃO INSTALADO NO 22º BATALHÃO DA POLÍCIA MILITAR, EM PALMAS/TO, CONTEMPLANDO INSPEÇÃO EM CAMPO, ANÁLISE DOS REGISTROS DISPONÍVEIS E EMISSÃO DE RELATÓRIO TÉCNICO CONTENDO CONCLUSÕES E RECOMENDAÇÕES TÉCNICAS', 'Baixa', '2026-07-03', 'Concluído', '2', 1, '2026-07-03', '2026-08-13 08:22:24', '2026-08-13 08:22:25', '2026-07-03 09:51:18', NULL),
('9a6cae0e', '2',  '3', 'Analise do projeto de Seletividade e proteção', 'Média', '2026-09-10', 'Em Andamento', '1000', 30, '2026-09-11', '2026-10-11 00:00:00', NULL, '2026-08-13 08:19:39', NULL),
('df2fa6ef', '3',  '3', 'Analise do projeto de Seletividade e proteção', 'Média', '2026-09-10', 'Em Andamento', '1000', 30, '2026-08-11', '2026-08-11 00:00:00', NULL, '2026-08-13 08:21:12', NULL),
('4b6fb4ac', 'f7a18331', '8', 'Proposta de execução do serviço.', 'Média', '2026-10-03', 'À Iniciar', '1', 3, NULL, NULL, NULL, '2026-10-01 14:23:35', NULL),
('c4f1652d', 'b96c353a', NULL, 'Teste', 'Alta', NULL, 'À Iniciar', '1', 5, NULL, NULL, NULL, '2026-10-04 16:50:08', NULL),
('f51f718e', 'b96c353a', NULL, 'Teste 5', 'Alta', '2026-10-15', 'À Iniciar', '1', 5, '2026-10-06', '2026-10-04 07:00:00', NULL, '2026-10-04 23:57:10', NULL);

-- ------------------------------------------------------------
-- 8. CRONOGRAMA  (aba Cronograma - alvo do link)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS cronograma (
    id_cronograma        TEXT PRIMARY KEY,
    id_obra              TEXT,
    obra                 TEXT,
    id_tarefa            TEXT,
    tarefa               TEXT,
    inicio               DATE,
    fim                  DATE,
    percentual_concluido TEXT,
    responsavel          TEXT,
    predecessora         TEXT,
    FOREIGN KEY (id_obra)   REFERENCES obras(id),
    FOREIGN KEY (id_tarefa) REFERENCES tarefas(id_tarefa)
);

INSERT INTO cronograma (id_cronograma, id_obra, obra, id_tarefa, tarefa, inicio, fim, percentual_concluido, responsavel, predecessora) VALUES
('CR001', '14', 'Hochschild', 'a26dd08a', 'Rede interna', '2026-04-20', '2026-04-29', '100%', 'Alexandre Magno', NULL),
('CR002', '14', 'Hochschild', 'ec473d97', 'Coletar resistividade', '2026-04-21', '2026-05-05', '100%', 'Alexandre Magno', NULL),
('CR003', '14', 'Hochschild', 'd138a3c9', 'Comprar materiais', '2026-04-01', '2026-05-08', '100%', 'Victor Emmanuel', NULL),
('CR004', '14', 'Hochschild', '7bb75203', 'Execução da SE', '2026-06-02', '2026-06-08', '0%', 'Alexandre Magno', NULL),
('CR005', '14', 'Hochschild', 'c8965f7c', 'Execução da rede Interna', '2026-06-02', '2026-06-02', '0%', 'Victor Emmanuel', NULL),
('CR006', '11', 'OPY', 'cf817b0f', 'Projeto de posto de transformação de 225KVA', '2026-04-06', '2026-04-08', '100%', 'Alexandre Magno', NULL),
('CR007', '11', 'OPY', '09efb314', 'Analise do projeto com apoio do Governo', '2026-04-17', '2026-05-17', '100%', 'Energisa', NULL),
('CR008', '2',  'LODI GERAÇÃO DE ENERGIA ELETRICA LTDA', '3825840e', 'Malha de aterramento', '2026-05-04', '2026-05-05', '100%', 'Alexandre Magno', NULL),
('CR009', '3',  'LODI GERAÇÃO DE ENERGIA ELETRICA LTDA', '1f843fa3', 'Malha de aterramento', '2026-05-04', '2026-05-05', '100%', 'Alexandre Magno', NULL),
('CR010', '2',  'LODI GERAÇÃO DE ENERGIA ELETRICA LTDA', '0fc03a3d', 'Projeto construtivo', '2026-05-04', '2026-05-04', '100%', 'Victor Emmanuel', NULL),
('CR011', '2',  'LODI GERAÇÃO DE ENERGIA ELETRICA LTDA', '20690850', 'Proteção e seletividade', '2026-05-04', '2026-05-04', '100%', 'Victor Emmanuel', NULL),
('CR012', '14', 'Hochschild', '3e94b2ec', 'Comissionar rede', '2026-06-08', '2026-07-07', '0%', 'Victor Emmanuel', NULL),
('CR013', '14', 'Hochschild', 'f0f0b954', 'Seletividade e proteção', '2026-04-27', '2026-05-04', '100%', 'Victor Emmanuel', NULL),
('CR014', '15baa0e0', 'JORGE PELIZON', '7bcff0e6', 'PROJETO SUBESTAÇÃO 500KVA', '2026-06-01', '2026-06-03', '0%', 'Victor Emmanuel', NULL),
('CR015', '7bff53de', 'Renato Neponuceno', '89be8c5a', '1.1. PRESTAÇÃO DE SERVIÇOS DE ANÁLISE TÉCNICA E DIAGNÓSTICO DE ATUAÇÃO DE RELIGADOR DE MÉDIA TENSÃO INSTALADO NO 22º BATALHÃO DA POLÍCIA MILITAR, EM PALMAS/TO, CONTENDO INSPEÇÃO EM CAMPO, ANÁLISE DOS REGISTROS DISPONÍVEIS E EMISSÃO DE RELATÓRIO TÉCNICO CONTENDO CONCLUSÕES E RECOMENDAÇÕES TÉCNICAS', '2026-07-03', '2026-07-03', '100%', 'Victor Emmanuel', NULL),
('CR016', '2',  'LODI GERAÇÃO DE ENERGIA ELETRICA LTDA', '9a6cae0e', 'Analise do projeto de Seletividade e proteção', '2026-09-11', '2026-09-11', '0%', 'Energisa', NULL),
('CR017', '3',  'LODI GERAÇÃO DE ENERGIA ELETRICA LTDA', 'df2fa6ef', 'Analise do projeto de Seletividade e proteção', '2026-08-11', '2026-09-10', '0%', 'Energisa', NULL),
('CR018', 'f7a18331', 'VIP EMPREENDIMENTO', '4b6fb4ac', 'Proposta de execução do serviço.', '2026-10-01', '2026-10-03', '0%', 'Alexandre Magno', NULL),
('886e6d77', 'b96c353a', 'Teste', 'c4f1652d', 'Teste', NULL, NULL, '0', 'Alexandre Magno', NULL),
('cb08d667', 'b96c353a', 'Teste', 'f51f718e', 'Teste 5', '2026-10-06', '2026-10-11', '0', 'Alexandre Magno', NULL);

-- ------------------------------------------------------------
-- 9. OBSERVAÇÕES DE OBRAS  (aba Obs_Geral)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS obs_geral (
    id         TEXT PRIMARY KEY,
    id_geral   TEXT,
    data       DATETIME,
    observacao TEXT,
    FOREIGN KEY (id_geral) REFERENCES obras(id)
);

INSERT INTO obs_geral (id, id_geral, data, observacao) VALUES
('99fc1ae5', '11', '2026-04-30 10:26:48', 'Depende de um apoio politico para aprovação do projeto'),
('384322d7', '4',  '2026-05-26 10:02:58', 'Sem retorno'),
('0407e75d', '5',  '2026-05-26 10:03:20', 'Sem retorno da proposta'),
('548f48b7', '6',  '2026-05-26 10:03:39', 'Sem retorno da proposta'),
('4883453f', '13', '2026-05-26 11:36:37', 'Outra empresa executando o serviço'),
('e72df431', '15', '2026-05-26 11:37:17', 'Outra empresa executando o serviço'),
('7f06ea44', '12', '2026-05-26 11:37:46', 'Não aceitou'),
('92192def', '9',  '2026-05-26 11:38:45', 'Outra empresa vai executar o serviço'),
('8d20fcf1', '8',  '2026-05-26 11:39:40', 'Energisa executou o serviço');

-- ------------------------------------------------------------
-- 10. OBSERVAÇÕES DE TAREFAS  (aba Obs_Tarefa)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS obs_tarefa (
    id         TEXT PRIMARY KEY,
    id_tarefa  TEXT,
    data       DATETIME,
    observacao TEXT,
    FOREIGN KEY (id_tarefa) REFERENCES tarefas(id_tarefa)
);

INSERT INTO obs_tarefa (id, id_tarefa, data, observacao) VALUES
('67589368', '09efb314', '2026-04-30 10:53:38', 'Entrou em pendente'),
('d874cb6d', 'a26dd08a', '2026-04-30 11:02:02', 'Entrou em pendente'),
('f1d8fc6b', 'a26dd08a', '2026-04-30 11:07:23', 'Entrou em pendente'),
('2ee47487', 'a26dd08a', '2026-04-30 11:07:29', 'Voltou o status para andamento'),
('c0216127', '09efb314', '2026-04-30 18:49:34', 'Voltou o status para andamento'),
('7a132fb5', '7bcff0e6', '2026-06-01 17:29:05', 'PROJETO SUBESTAÇÃO DE 500KVA'),
('deee10d7', '89be8c5a', '2026-07-03 10:39:10', NULL);

-- ------------------------------------------------------------
-- 11. HISTÓRICO DE STATUS  (aba historico_status_geral)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS historico_status_geral (
    id              TEXT PRIMARY KEY,
    id_geral        TEXT,
    status_anterior TEXT,
    status_novo     TEXT,
    data            DATETIME,
    usuario         TEXT,
    FOREIGN KEY (id_geral) REFERENCES obras(id)
);

INSERT INTO historico_status_geral (id, id_geral, status_anterior, status_novo, data, usuario) VALUES
('14f2b064', '2',          'CONTRATO EM ANDAMENTO', 'CONTRATO ENCERRADO', '2026-10-04 15:56:51', 'Alexandre Magno'),
('cb757d8f', '2',          'CONTRATO ENCERRADO',    'CONTRATO ENCERRADO', '2026-10-04 15:56:54', 'Alexandre Magno'),
('6f38e182', '3',          'CONTRATO EM ANDAMENTO', 'CONTRATO ENCERRADO', '2026-10-04 15:57:06', 'Alexandre Magno'),
('48b9e29c', 'b96c353a',   'CADASTRADA',            'ELABORAÇÃO DA PROPOSTA', '2026-10-04 16:23:36', 'Alexandre Magno'),
('39303a8e', 'b96c353a',   'ELABORAÇÃO DA PROPOSTA','PROPOSTA ENVIADA',   '2026-10-04 16:23:53', 'Alexandre Magno'),
('1c9904b8', 'b96c353a',   'PROPOSTA ENVIADA',      'CONTRATO EM ANDAMENTO', '2026-10-04 16:24:07', 'Alexandre Magno');

-- ------------------------------------------------------------
-- ÍNDICES (velocidade nas consultas do site)
-- ------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_obras_status        ON obras(status);
CREATE INDEX IF NOT EXISTS idx_obras_interessado   ON obras(interessado);
CREATE INDEX IF NOT EXISTS idx_tarefas_projeto     ON tarefas(id_projeto);
CREATE INDEX IF NOT EXISTS idx_tarefas_status      ON tarefas(status);
CREATE INDEX IF NOT EXISTS idx_cronograma_obra     ON cronograma(id_obra);
CREATE INDEX IF NOT EXISTS idx_cronograma_tarefa   ON cronograma(id_tarefa);
CREATE INDEX IF NOT EXISTS idx_obs_geral_id        ON obs_geral(id_geral);
CREATE INDEX IF NOT EXISTS idx_obs_tarefa_id       ON obs_tarefa(id_tarefa);
CREATE INDEX IF NOT EXISTS idx_historico_geral     ON historico_status_geral(id_geral);

COMMIT;

-- ============================================================
-- FIM DO SCRIPT
-- ============================================================