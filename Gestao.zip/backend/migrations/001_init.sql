-- 001_init.sql — esquema inicial do Dashboard Gestão de Obras
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS usuarios (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  senha_hash TEXT NOT NULL DEFAULT '',
  cargo TEXT DEFAULT '',
  departamento TEXT DEFAULT '',
  telefone TEXT DEFAULT '',
  papel TEXT NOT NULL DEFAULT 'visualizador'
    CHECK (papel IN ('admin','gestor','visualizador')),
  situacao TEXT NOT NULL DEFAULT 'ATIVO'
    CHECK (situacao IN ('ATIVO','INATIVO')),
  data_cadastro TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  data_desativado TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS obras (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  cod TEXT DEFAULT '',
  interessado TEXT DEFAULT '',
  endereco TEXT DEFAULT '',
  responsavel TEXT DEFAULT '',
  telefone TEXT DEFAULT '',
  tipo_proposta TEXT DEFAULT '',
  responsavel_dineng TEXT DEFAULT '',
  cadastro TEXT DEFAULT '',
  data_solicitacao TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'CADASTRADA',
  data_envio TEXT DEFAULT '',
  data_novo_status TEXT DEFAULT '',
  status_anterior TEXT DEFAULT '',
  aparelho TEXT DEFAULT '',
  criado_em TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  atualizado_em TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE IF NOT EXISTS tarefas (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  id_projeto INTEGER REFERENCES obras(id) ON DELETE SET NULL,
  nome TEXT NOT NULL,
  descricao TEXT DEFAULT '',
  prioridade TEXT DEFAULT 'Média',
  data_vencimento TEXT DEFAULT '',
  status TEXT DEFAULT 'A fazer',
  id_responsavel INTEGER REFERENCES usuarios(id) ON DELETE SET NULL,
  esforco TEXT DEFAULT '',
  previsao_inicio TEXT DEFAULT '',
  data_inicio TEXT DEFAULT '',
  data_conclusao TEXT DEFAULT '',
  data_criacao TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  observacao TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS cronograma (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  id_obra INTEGER REFERENCES obras(id) ON DELETE CASCADE,
  obra TEXT DEFAULT '',
  id_tarefa INTEGER REFERENCES tarefas(id) ON DELETE CASCADE,
  name TEXT DEFAULT '',
  start TEXT DEFAULT '',
  end TEXT DEFAULT '',
  progress REAL DEFAULT 0,
  responsavel TEXT DEFAULT '',
  predecessor TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS status (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tipo TEXT NOT NULL, -- 'obra' | 'tarefa' | 'financeiro' | 'tipo_proposta'
  nome TEXT NOT NULL,
  prazo INTEGER DEFAULT 0,
  sequencia INTEGER DEFAULT 0,
  UNIQUE (tipo, nome)
);

CREATE TABLE IF NOT EXISTS observacoes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tipo TEXT NOT NULL CHECK (tipo IN ('obra','tarefa')),
  id_referencia INTEGER NOT NULL,
  data TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  observacao TEXT DEFAULT '',
  autor_id INTEGER REFERENCES usuarios(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS historico (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  id_obra INTEGER REFERENCES obras(id) ON DELETE CASCADE,
  status_anterior TEXT DEFAULT '',
  novo_status TEXT DEFAULT '',
  data TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  responsavel TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS arquivos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  drive_file_id TEXT NOT NULL,
  obra_id INTEGER REFERENCES obras(id) ON DELETE CASCADE,
  nome TEXT NOT NULL,
  mime_type TEXT DEFAULT '',
  enviado_por INTEGER REFERENCES usuarios(id) ON DELETE SET NULL,
  enviado_em TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE INDEX IF NOT EXISTS idx_obras_status ON obras(status);
CREATE INDEX IF NOT EXISTS idx_tarefas_projeto ON tarefas(id_projeto);
CREATE INDEX IF NOT EXISTS idx_obs_referencia ON observacoes(tipo, id_referencia);
CREATE INDEX IF NOT EXISTS idx_historico_obra ON historico(id_obra);
