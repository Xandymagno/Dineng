// =========================================================
// routes/cronograma.routes.js — Cronograma
// =========================================================
const { Router } = require('express');
const { validar } = require('../middlewares/validate');
const { autenticar, exigirPapel } = require('../middlewares/auth');
const { cronogramaSchema } = require('../schemas/cronograma.schema');
const cronogramaController = require('../controllers/cronograma.controller');

const router = Router();

router.use(autenticar);

router.get('/', cronogramaController.listar);
router.post('/', exigirPapel('admin', 'gestor'), validar(cronogramaSchema), cronogramaController.salvar);
router.delete('/:id', exigirPapel('admin'), cronogramaController.excluir);

module.exports = router;
