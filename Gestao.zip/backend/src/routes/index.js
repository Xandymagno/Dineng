// =========================================================
// routes/index.js — Agrega todas as rotas da API
// =========================================================
const { Router } = require('express');
const authRoutes = require('./auth.routes');
const obrasRoutes = require('./obras.routes');
const tarefasRoutes = require('./tarefas.routes');
const cronogramaRoutes = require('./cronograma.routes');
const usuariosRoutes = require('./usuarios.routes');
const statusRoutes = require('./status.routes');
const historicoRoutes = require('./historico.routes');
const relatorioRoutes = require('./relatorio.routes');

const router = Router();

router.use('/auth', authRoutes);
router.use('/obras', obrasRoutes);
router.use('/tarefas', tarefasRoutes);
router.use('/cronograma', cronogramaRoutes);
router.use('/usuarios', usuariosRoutes);
router.use('/status', statusRoutes);
router.use('/historico', historicoRoutes);
router.use('/relatorio', relatorioRoutes);

module.exports = router;
