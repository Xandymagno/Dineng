// =========================================================
// routes/relatorio.routes.js — Relatório (leitura)
// =========================================================
const { Router } = require('express');
const { autenticar } = require('../middlewares/auth');
const relatorioController = require('../controllers/relatorio.controller');

const router = Router();

router.use(autenticar);

router.get('/', relatorioController.listar);

module.exports = router;
