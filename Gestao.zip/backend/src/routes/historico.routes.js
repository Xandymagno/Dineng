// =========================================================
// routes/historico.routes.js — Histórico de status
// =========================================================
const { Router } = require('express');
const { autenticar } = require('../middlewares/auth');
const historicoController = require('../controllers/historico.controller');

const router = Router();

router.use(autenticar);

router.get('/', historicoController.listar);

module.exports = router;
