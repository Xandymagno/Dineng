// =========================================================
// routes/status.routes.js — Status e listas de apoio
// =========================================================
const { Router } = require('express');
const { autenticar } = require('../middlewares/auth');
const statusController = require('../controllers/status.controller');

const router = Router();

router.use(autenticar);

router.get('/geral', statusController.geral);
router.get('/tarefas', statusController.tarefas);
router.get('/financeiro', statusController.financeiro);
router.get('/tipos-proposta', statusController.tiposProposta);

module.exports = router;
