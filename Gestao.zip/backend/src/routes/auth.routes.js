// =========================================================
// routes/auth.routes.js — Autenticação
// =========================================================
const { Router } = require('express');
const { validar } = require('../middlewares/validate');
const { autenticar } = require('../middlewares/auth');
const { loginSchema, definirSenhaSchema } = require('../schemas/auth.schema');
const authController = require('../controllers/auth.controller');

const router = Router();

router.post('/login', validar(loginSchema), authController.login);
router.post('/senha', validar(definirSenhaSchema), authController.definirSenha);
router.get('/me', autenticar, authController.me);
router.post('/logout', authController.logout);

module.exports = router;
