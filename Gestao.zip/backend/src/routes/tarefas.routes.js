// =========================================================
// routes/tarefas.routes.js — Tarefas
// =========================================================
const { Router } = require('express');
const { validar } = require('../middlewares/validate');
const { autenticar, exigirPapel } = require('../middlewares/auth');
const { tarefaSchema } = require('../schemas/tarefa.schema');
const tarefasController = require('../controllers/tarefas.controller');

const router = Router();

router.use(autenticar);

router.get('/', tarefasController.listar);
router.get('/:id', tarefasController.buscar);
router.post('/', exigirPapel('admin', 'gestor'), validar(tarefaSchema), tarefasController.criar);
router.put('/:id', exigirPapel('admin', 'gestor'), validar(tarefaSchema), tarefasController.atualizar);
router.delete('/:id', exigirPapel('admin'), tarefasController.excluir);

module.exports = router;
