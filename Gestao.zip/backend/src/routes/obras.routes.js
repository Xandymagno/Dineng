// =========================================================
// routes/obras.routes.js — Obras
// =========================================================
const { Router } = require('express');
const { validar } = require('../middlewares/validate');
const { autenticar, exigirPapel } = require('../middlewares/auth');
const { obraSchema, avancarStatusSchema } = require('../schemas/obra.schema');
const obrasController = require('../controllers/obras.controller');

const router = Router();

router.use(autenticar);

router.get('/', obrasController.listar);
router.get('/:id', obrasController.buscar);
router.post('/', exigirPapel('admin', 'gestor'), validar(obraSchema), obrasController.criar);
router.put('/:id', exigirPapel('admin', 'gestor'), validar(obraSchema), obrasController.atualizar);
router.delete('/:id', exigirPapel('admin'), obrasController.excluir);
router.post('/:id/avancar-status', exigirPapel('admin', 'gestor'), validar(avancarStatusSchema), obrasController.avancarStatus);

module.exports = router;
