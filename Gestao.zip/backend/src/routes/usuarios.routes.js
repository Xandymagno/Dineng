// =========================================================
// routes/usuarios.routes.js — Usuários
// =========================================================
const { Router } = require('express');
const { validar } = require('../middlewares/validate');
const { autenticar, exigirPapel } = require('../middlewares/auth');
const { usuarioSchema, situacaoSchema } = require('../schemas/usuario.schema');
const usuariosController = require('../controllers/usuarios.controller');

const router = Router();

router.use(autenticar);

router.get('/', exigirPapel('admin', 'gestor'), usuariosController.listar);
router.post('/', exigirPapel('admin'), validar(usuarioSchema), usuariosController.criar);
router.put('/:id', exigirPapel('admin'), validar(usuarioSchema), usuariosController.atualizar);
router.patch('/:id/situacao', exigirPapel('admin'), validar(situacaoSchema), usuariosController.definirSituacao);

module.exports = router;
