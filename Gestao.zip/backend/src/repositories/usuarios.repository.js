// =========================================================
// repositories/usuarios.repository.js — Acesso a dados de usuários
// =========================================================
const db = require('../config/db');

function listar() {
  return db.prepare(`
    SELECT id, nome, email, cargo, departamento, telefone, papel,
           situacao, data_cadastro, data_desativado,
           CASE WHEN senha_hash = '' THEN 0 ELSE 1 END AS tem_senha
    FROM usuarios
    ORDER BY nome
  `).all();
}

function buscarPorId(id) {
  return db.prepare('SELECT * FROM usuarios WHERE id = ?').get(id);
}

function buscarPorEmail(email) {
  return db.prepare('SELECT * FROM usuarios WHERE email = ?').get(email);
}

function criar(dados) {
  const info = db.prepare(`
    INSERT INTO usuarios (nome, email, senha_hash, cargo, departamento, telefone, papel, situacao)
    VALUES (@nome, @email, @senha_hash, @cargo, @departamento, @telefone, @papel, @situacao)
  `).run(dados);
  return buscarPorId(info.lastInsertRowid);
}

function atualizar(id, dados) {
  db.prepare(`
    UPDATE usuarios SET
      nome = @nome, email = @email, senha_hash = @senha_hash,
      cargo = @cargo, departamento = @departamento, telefone = @telefone,
      papel = @papel, situacao = @situacao
    WHERE id = @id
  `).run({ ...dados, id });
  return buscarPorId(id);
}

function atualizarSenha(id, senha_hash) {
  db.prepare('UPDATE usuarios SET senha_hash = ? WHERE id = ?').run(senha_hash, id);
  return buscarPorId(id);
}

function definirSituacao(id, situacao) {
  const dataDesativado = situacao === 'INATIVO' ? new Date().toISOString() : '';
  db.prepare('UPDATE usuarios SET situacao = ?, data_desativado = ? WHERE id = ?')
    .run(situacao, dataDesativado, id);
  return buscarPorId(id);
}

module.exports = { listar, buscarPorId, buscarPorEmail, criar, atualizar, atualizarSenha, definirSituacao };
