// =========================================================
// repositories/observacoes.repository.js — Observações
// =========================================================
const db = require('../config/db');

function listarPorReferencia(tipo, idReferencia) {
  return db.prepare(`
    SELECT id, tipo, id_referencia, data, observacao, autor_id
    FROM observacoes
    WHERE tipo = ? AND id_referencia = ?
    ORDER BY data DESC
  `).all(tipo, idReferencia);
}

function criar(dados) {
  const info = db.prepare(`
    INSERT INTO observacoes (tipo, id_referencia, observacao, autor_id)
    VALUES (@tipo, @id_referencia, @observacao, @autor_id)
  `).run(dados);
  return db.prepare('SELECT * FROM observacoes WHERE id = ?').get(info.lastInsertRowid);
}

function excluir(id) {
  return db.prepare('DELETE FROM observacoes WHERE id = ?').run(id);
}

module.exports = { listarPorReferencia, criar, excluir };
