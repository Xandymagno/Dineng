// =========================================================
// repositories/cronograma.repository.js — Acesso ao cronograma
// =========================================================
const db = require('../config/db');

function listar() {
  return db.prepare('SELECT * FROM cronograma ORDER BY start').all();
}

function buscarPorId(id) {
  return db.prepare('SELECT * FROM cronograma WHERE id = ?').get(id);
}

function criar(dados) {
  const info = db.prepare(`
    INSERT INTO cronograma (id_obra, obra, id_tarefa, name, start, end, progress, responsavel, predecessor)
    VALUES (@id_obra, @obra, @id_tarefa, @name, @start, @end, @progress, @responsavel, @predecessor)
  `).run(dados);
  return buscarPorId(info.lastInsertRowid);
}

function atualizar(id, dados) {
  db.prepare(`
    UPDATE cronograma SET
      id_obra = @id_obra, obra = @obra, id_tarefa = @id_tarefa, name = @name,
      start = @start, end = @end, progress = @progress,
      responsavel = @responsavel, predecessor = @predecessor
    WHERE id = @id
  `).run({ ...dados, id });
  return buscarPorId(id);
}

function excluir(id) {
  return db.prepare('DELETE FROM cronograma WHERE id = ?').run(id);
}

module.exports = { listar, buscarPorId, criar, atualizar, excluir };
