// =========================================================
// repositories/status.repository.js — Listas de status
// =========================================================
const db = require('../config/db');

function listarPorTipo(tipo) {
  return db.prepare('SELECT * FROM status WHERE tipo = ? ORDER BY sequencia').all(tipo);
}

module.exports = { listarPorTipo };
