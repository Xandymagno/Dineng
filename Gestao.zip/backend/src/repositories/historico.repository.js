// =========================================================
// repositories/historico.repository.js — Histórico de status
// =========================================================
const db = require('../config/db');

function listar(idObra) {
  if (idObra) {
    return db.prepare('SELECT * FROM historico WHERE id_obra = ? ORDER BY data DESC').all(idObra);
  }
  return db.prepare('SELECT * FROM historico ORDER BY data DESC').all();
}

function criar(dados) {
  const info = db.prepare(`
    INSERT INTO historico (id_obra, status_anterior, novo_status, responsavel)
    VALUES (@id_obra, @status_anterior, @novo_status, @responsavel)
  `).run(dados);
  return db.prepare('SELECT * FROM historico WHERE id = ?').get(info.lastInsertRowid);
}

module.exports = { listar, criar };
