// =========================================================
// repositories/obras.repository.js — Acesso a dados de obras
// =========================================================
const db = require('../config/db');

function listar() {
  return db.prepare('SELECT * FROM obras ORDER BY cod').all();
}

function buscarPorId(id) {
  return db.prepare('SELECT * FROM obras WHERE id = ?').get(id);
}

function proximoCod() {
  const linha = db.prepare('SELECT COUNT(*) AS total FROM obras').get();
  return String(linha.total + 1);
}

function criar(dados) {
  const info = db.prepare(`
    INSERT INTO obras (
      cod, interessado, endereco, responsavel, telefone, tipo_proposta,
      responsavel_dineng, cadastro, data_solicitacao, status, data_envio,
      data_novo_status, status_anterior, aparelho
    ) VALUES (
      @cod, @interessado, @endereco, @responsavel, @telefone, @tipo_proposta,
      @responsavel_dineng, @cadastro, @data_solicitacao, @status, @data_envio,
      @data_novo_status, @status_anterior, @aparelho
    )
  `).run(dados);
  return buscarPorId(info.lastInsertRowid);
}

function atualizar(id, dados) {
  db.prepare(`
    UPDATE obras SET
      cod = @cod, interessado = @interessado, endereco = @endereco,
      responsavel = @responsavel, telefone = @telefone, tipo_proposta = @tipo_proposta,
      responsavel_dineng = @responsavel_dineng, cadastro = @cadastro,
      data_solicitacao = @data_solicitacao, status = @status, data_envio = @data_envio,
      data_novo_status = @data_novo_status, status_anterior = @status_anterior,
      aparelho = @aparelho,
      atualizado_em = strftime('%Y-%m-%dT%H:%M:%fZ','now')
    WHERE id = @id
  `).run({ ...dados, id });
  return buscarPorId(id);
}

function excluir(id) {
  return db.prepare('DELETE FROM obras WHERE id = ?').run(id);
}

module.exports = { listar, buscarPorId, proximoCod, criar, atualizar, excluir };
