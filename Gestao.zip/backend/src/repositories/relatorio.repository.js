// =========================================================
// repositories/relatorio.repository.js — Relatório (view)
// =========================================================
const db = require('../config/db');

function listar() {
  return db.prepare(`
    SELECT
      o.interessado,
      o.status AS etapa,
      t.nome AS descricao,
      t.status AS status_tarefa,
      o.responsavel,
      o.telefone,
      u.email,
      t.data_vencimento AS vencimento
    FROM obras o
    LEFT JOIN tarefas t ON t.id_projeto = o.id
    LEFT JOIN usuarios u ON u.id = t.id_responsavel
    ORDER BY o.cod
  `).all();
}

module.exports = { listar };
