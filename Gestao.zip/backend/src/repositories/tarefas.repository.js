// =========================================================
// repositories/tarefas.repository.js — Acesso a dados de tarefas
// =========================================================
const db = require('../config/db');

function listar() {
  return db.prepare('SELECT * FROM tarefas ORDER BY data_vencimento').all();
}

function buscarPorId(id) {
  return db.prepare('SELECT * FROM tarefas WHERE id = ?').get(id);
}

function criar(dados) {
  const info = db.prepare(`
    INSERT INTO tarefas (
      id_projeto, nome, descricao, prioridade, data_vencimento, status,
      id_responsavel, esforco, previsao_inicio, data_inicio, data_conclusao, observacao
    ) VALUES (
      @id_projeto, @nome, @descricao, @prioridade, @data_vencimento, @status,
      @id_responsavel, @esforco, @previsao_inicio, @data_inicio, @data_conclusao, @observacao
    )
  `).run(dados);
  return buscarPorId(info.lastInsertRowid);
}

function atualizar(id, dados) {
  db.prepare(`
    UPDATE tarefas SET
      id_projeto = @id_projeto, nome = @nome, descricao = @descricao,
      prioridade = @prioridade, data_vencimento = @data_vencimento, status = @status,
      id_responsavel = @id_responsavel, esforco = @esforco,
      previsao_inicio = @previsao_inicio, data_inicio = @data_inicio,
      data_conclusao = @data_conclusao, observacao = @observacao
    WHERE id = @id
  `).run({ ...dados, id });
  return buscarPorId(id);
}

function excluir(id) {
  return db.prepare('DELETE FROM tarefas WHERE id = ?').run(id);
}

module.exports = { listar, buscarPorId, criar, atualizar, excluir };
