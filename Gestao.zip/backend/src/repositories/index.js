// =========================================================
// repositories/index.js — Centraliza o acesso a dados
// =========================================================
const db = require('../config/db');

module.exports = {
  db,
  usuarios: require('./usuarios.repository'),
  obras: require('./obras.repository'),
  tarefas: require('./tarefas.repository'),
  cronograma: require('./cronograma.repository'),
  status: require('./status.repository'),
  observacoes: require('./observacoes.repository'),
  historico: require('./historico.repository'),
  relatorio: require('./relatorio.repository')
};
