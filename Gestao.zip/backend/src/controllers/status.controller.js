// =========================================================
// controllers/status.controller.js — Status e listas
// =========================================================
const statusService = require('../services/status.service');

async function geral(req, res, next) {
  try {
    const status = await statusService.geral();
    return res.json({ success: true, status });
  } catch (erro) { return next(erro); }
}

async function tarefas(req, res, next) {
  try {
    const status = await statusService.tarefas();
    return res.json({ success: true, status });
  } catch (erro) { return next(erro); }
}

async function financeiro(req, res, next) {
  try {
    const status = await statusService.financeiro();
    return res.json({ success: true, status });
  } catch (erro) { return next(erro); }
}

async function tiposProposta(req, res, next) {
  try {
    const tipos = await statusService.tiposProposta();
    return res.json({ success: true, tipos });
  } catch (erro) { return next(erro); }
}

module.exports = { geral, tarefas, financeiro, tiposProposta };
