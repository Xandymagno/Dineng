// =========================================================
// controllers/obras.controller.js — Obras
// =========================================================
const obrasService = require('../services/obras.service');

async function listar(req, res, next) {
  try {
    const obras = await obrasService.listar();
    return res.json({ success: true, obras });
  } catch (erro) { return next(erro); }
}

async function buscar(req, res, next) {
  try {
    const obra = await obrasService.buscar(Number(req.params.id));
    return res.json({ success: true, obra });
  } catch (erro) { return next(erro); }
}

async function criar(req, res, next) {
  try {
    const obra = await obrasService.criar(req.body);
    return res.status(201).json({ success: true, obra });
  } catch (erro) { return next(erro); }
}

async function atualizar(req, res, next) {
  try {
    const obra = await obrasService.atualizar(Number(req.params.id), req.body);
    return res.json({ success: true, obra });
  } catch (erro) { return next(erro); }
}

async function excluir(req, res, next) {
  try {
    await obrasService.excluir(Number(req.params.id));
    return res.json({ success: true });
  } catch (erro) { return next(erro); }
}

async function avancarStatus(req, res, next) {
  try {
    const resultado = await obrasService.avancarStatus(Number(req.params.id), req.body);
    return res.json({ success: true, ...resultado });
  } catch (erro) { return next(erro); }
}

module.exports = { listar, buscar, criar, atualizar, excluir, avancarStatus };
