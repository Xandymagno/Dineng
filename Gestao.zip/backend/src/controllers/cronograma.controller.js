// =========================================================
// controllers/cronograma.controller.js — Cronograma
// =========================================================
const cronogramaService = require('../services/cronograma.service');

async function listar(req, res, next) {
  try {
    const tarefas = await cronogramaService.listar();
    return res.json({ success: true, tarefas });
  } catch (erro) { return next(erro); }
}

async function salvar(req, res, next) {
  try {
    const item = await cronogramaService.salvar(req.body);
    return res.json({ success: true, item });
  } catch (erro) { return next(erro); }
}

async function excluir(req, res, next) {
  try {
    await cronogramaService.excluir(Number(req.params.id));
    return res.json({ success: true });
  } catch (erro) { return next(erro); }
}

module.exports = { listar, salvar, excluir };
