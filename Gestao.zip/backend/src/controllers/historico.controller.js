// =========================================================
// controllers/historico.controller.js — Histórico
// =========================================================
const historicoService = require('../services/historico.service');

async function listar(req, res, next) {
  try {
    const historico = await historicoService.listar(req.query.obra);
    return res.json({ success: true, historico });
  } catch (erro) { return next(erro); }
}

module.exports = { listar };
