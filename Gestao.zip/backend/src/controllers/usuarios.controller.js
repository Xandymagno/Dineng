// =========================================================
// controllers/usuarios.controller.js — Usuários
// =========================================================
const usuariosService = require('../services/usuarios.service');

async function listar(req, res, next) {
  try {
    const usuarios = await usuariosService.listar();
    return res.json({ success: true, usuarios });
  } catch (erro) { return next(erro); }
}

async function criar(req, res, next) {
  try {
    const usuario = await usuariosService.criar(req.body);
    return res.status(201).json({ success: true, usuario });
  } catch (erro) { return next(erro); }
}

async function atualizar(req, res, next) {
  try {
    const usuario = await usuariosService.atualizar(Number(req.params.id), req.body);
    return res.json({ success: true, usuario });
  } catch (erro) { return next(erro); }
}

async function definirSituacao(req, res, next) {
  try {
    const usuario = await usuariosService.definirSituacao(Number(req.params.id), req.body);
    return res.json({ success: true, usuario });
  } catch (erro) { return next(erro); }
}

module.exports = { listar, criar, atualizar, definirSituacao };
