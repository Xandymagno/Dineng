// =========================================================
// controllers/auth.controller.js — Autenticação
// =========================================================
const authService = require('../services/auth.service');

async function login(req, res, next) {
  try {
    const { token, usuario } = await authService.login(req.body);
    res.cookie('token', token, {
      httpOnly: true,
      secure: process.env.COOKIE_SECURE === 'true',
      sameSite: 'lax',
      maxAge: 8 * 60 * 60 * 1000
    });
    return res.json({ success: true, usuario });
  } catch (erro) {
    return next(erro);
  }
}

async function definirSenha(req, res, next) {
  try {
    await authService.definirSenha(req.body);
    return res.json({ success: true, mensagem: 'Senha definida' });
  } catch (erro) {
    return next(erro);
  }
}

async function me(req, res) {
  return res.json({ success: true, usuario: req.usuario });
}

function logout(req, res) {
  res.clearCookie('token');
  return res.json({ success: true });
}

module.exports = { login, definirSenha, me, logout };
