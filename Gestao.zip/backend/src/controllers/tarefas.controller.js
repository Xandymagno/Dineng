// =========================================================
// controllers/tarefas.controller.js — Tarefas
// =========================================================
const tarefasService = require('../services/tarefas.service');

async function listar(req, res, next) {
  try {
    const tarefas = await tarefasService.listar();
    return res.json({ success: true, tarefas });
  } catch (erro) { return next(erro); }
}

async function buscar(req, res, next) {
  try {
    const tarefa = await tarefasService.buscar(Number(req.params.id));
    return res.json({ success: true, tarefa });
  } catch (erro) { return next(erro); }
}

async function criar(req, res, next) {
  try {
    const tarefa = await tarefasService.criar(req.body);
    return res.status(201).json({ success: true, tarefa });
  } catch (erro) { return next(erro); }
}

async function atualizar(req, res, next) {
  try {
    const tarefa = await tarefasService.atualizar(Number(req.params.id), req.body);
    return res.json({ success: true, tarefa });
  } catch (erro) { return next(erro); }
}

async function excluir(req, res, next) {
  try {
    await tarefasService.excluir(Number(req.params.id));
    return res.json({ success: true });
  } catch (erro) { return next(erro); }
}

module.exports = { listar, buscar, criar, atualizar, excluir };
