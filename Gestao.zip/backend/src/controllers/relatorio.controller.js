// =========================================================
// controllers/relatorio.controller.js — Relatório
// =========================================================
const relatorioService = require('../services/relatorio.service');

async function listar(req, res, next) {
  try {
    const relatorio = await relatorioService.listar();
    return res.json({ success: true, relatorio });
  } catch (erro) { return next(erro); }
}

module.exports = { listar };
