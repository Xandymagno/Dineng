// =========================================================
// schemas/cronograma.schema.js — Validação do cronograma
// =========================================================
const { z } = require('zod');

const dataISO = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}(T\d{2}:\d{2}(:\d{2}(\.\d{3}Z?)?)?)?$/, 'Data deve estar em ISO 8601')
  .optional()
  .or(z.literal(''));

const cronogramaSchema = z.object({
  id: z.number().int().positive().optional(),
  id_obra: z.number().int().positive().nullable().optional(),
  obra: z.string().max(200).optional().default(''),
  id_tarefa: z.number().int().positive().nullable().optional(),
  name: z.string().min(1).max(200),
  start: dataISO,
  end: dataISO,
  progress: z.number().min(0).max(100).optional().default(0),
  responsavel: z.string().max(200).optional().default(''),
  predecessor: z.string().max(200).optional().default('')
});

module.exports = { cronogramaSchema };
