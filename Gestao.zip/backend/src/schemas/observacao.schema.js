// =========================================================
// schemas/observacao.schema.js — Validação de observações
// =========================================================
const { z } = require('zod');

const observacaoSchema = z.object({
  id: z.number().int().positive().optional(),
  tipo: z.enum(['obra', 'tarefa']),
  id_referencia: z.number().int().positive(),
  data: z.string().optional().default(''),
  observacao: z.string().min(1).max(2000),
  autor_id: z.number().int().positive().nullable().optional()
});

module.exports = { observacaoSchema };
