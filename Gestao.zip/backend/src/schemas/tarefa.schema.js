// =========================================================
// schemas/tarefa.schema.js — Validação de tarefas
// =========================================================
const { z } = require('zod');

const dataISO = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}(T\d{2}:\d{2}(:\d{2}(\.\d{3}Z?)?)?)?$/, 'Data deve estar em ISO 8601')
  .optional()
  .or(z.literal(''));

const tarefaSchema = z.object({
  id: z.number().int().positive().optional(),
  id_projeto: z.number().int().positive().nullable().optional(),
  nome: z.string().min(1).max(200),
  descricao: z.string().max(1000).optional().default(''),
  prioridade: z.enum(['Baixa', 'Média', 'Alta', 'Urgente']).optional().default('Média'),
  data_vencimento: dataISO,
  status: z.string().max(50).optional().default('A fazer'),
  id_responsavel: z.number().int().positive().nullable().optional(),
  esforco: z.string().max(50).optional().default(''),
  previsao_inicio: dataISO,
  data_inicio: dataISO,
  data_conclusao: dataISO,
  data_criacao: dataISO,
  observacao: z.string().max(2000).optional().default('')
});

module.exports = { tarefaSchema };
