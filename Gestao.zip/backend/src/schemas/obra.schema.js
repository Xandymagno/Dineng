// =========================================================
// schemas/obra.schema.js — Validação de obras
// =========================================================
const { z } = require('zod');

const dataISO = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}(T\d{2}:\d{2}(:\d{2}(\.\d{3}Z?)?)?)?$/, 'Data deve estar em ISO 8601')
  .optional()
  .or(z.literal(''));

const obraSchema = z.object({
  id: z.number().int().positive().optional(),
  cod: z.string().max(20).optional().default(''),
  interessado: z.string().max(200).optional().default(''),
  endereco: z.string().max(300).optional().default(''),
  responsavel: z.string().max(200).optional().default(''),
  telefone: z.string().max(30).optional().default(''),
  tipo_proposta: z.string().max(100).optional().default(''),
  responsavel_dineng: z.string().max(200).optional().default(''),
  cadastro: dataISO,
  data_solicitacao: dataISO,
  status: z.string().max(50).optional().default('CADASTRADA'),
  data_envio: dataISO,
  data_novo_status: dataISO,
  status_anterior: z.string().max(50).optional().default(''),
  aparelho: z.string().max(100).optional().default('')
});

const avancarStatusSchema = z.object({
  id_obra: z.number().int().positive(),
  novo_status: z.string().min(1).max(50),
  responsavel: z.string().max(200).optional().default('')
});

module.exports = { obraSchema, avancarStatusSchema };
