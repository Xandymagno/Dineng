// =========================================================
// schemas/usuario.schema.js — Validação de usuários
// =========================================================
const { z } = require('zod');

const usuarioSchema = z.object({
  id: z.number().int().positive().optional(),
  nome: z.string().min(1).max(200),
  email: z.string().email('E-mail inválido').trim().toLowerCase(),
  senha: z.string().min(6).max(200).optional().default(''),
  cargo: z.string().max(100).optional().default(''),
  departamento: z.string().max(100).optional().default(''),
  telefone: z.string().max(30).optional().default(''),
  papel: z.enum(['admin', 'gestor', 'visualizador']).optional().default('visualizador'),
  situacao: z.enum(['ATIVO', 'INATIVO']).optional().default('ATIVO'),
  data_cadastro: z.string().optional().default(''),
  data_desativado: z.string().optional().default('')
});

const situacaoSchema = z.object({
  situacao: z.enum(['ATIVO', 'INATIVO'])
});

module.exports = { usuarioSchema, situacaoSchema };
