// =========================================================
// schemas/auth.schema.js — Validação de autenticação
// =========================================================
const { z } = require('zod');

const loginSchema = z.object({
  email: z.string().email('E-mail inválido').trim().toLowerCase(),
  senha: z.string().max(200).optional().default('')
});

const definirSenhaSchema = z.object({
  email: z.string().email('E-mail inválido').trim().toLowerCase(),
  senha: z.string().min(6, 'Mínimo 6 caracteres').max(200).optional().default('')
});

module.exports = { loginSchema, definirSenhaSchema };
