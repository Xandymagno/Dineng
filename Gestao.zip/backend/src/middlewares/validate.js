// =========================================================
// middlewares/validate.js — Validação de entrada (zod)
// =========================================================
function validar(schema) {
  return (req, res, next) => {
    const resultado = schema.safeParse(req.body);
    if (!resultado.success) {
      return res.status(400).json({
        success: false,
        erro: 'Dados inválidos',
        detalhes: resultado.error.flatten()
      });
    }
    req.body = resultado.data;
    next();
  };
}

module.exports = { validar };
