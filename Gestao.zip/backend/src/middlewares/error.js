// =========================================================
// middlewares/error.js — Tratamento central de erros
// =========================================================
function tratarErro(err, req, res, next) {
  console.error(err);
  res.status(err.status || 500).json({ success: false, erro: err.message || 'Erro interno' });
}

module.exports = { tratarErro };
