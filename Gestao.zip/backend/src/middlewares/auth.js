// =========================================================
// middlewares/auth.js — Autenticação e autorização
// =========================================================
const jwt = require('jsonwebtoken');

function autenticar(req, res, next) {
  const token = req.cookies?.token;
  if (!token) return res.status(401).json({ success: false, erro: 'Não autenticado' });
  try {
    req.usuario = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ success: false, erro: 'Sessão inválida ou expirada' });
  }
}

function exigirPapel(...papeis) {
  return (req, res, next) => {
    if (!req.usuario || !papeis.includes(req.usuario.papel)) {
      return res.status(403).json({ success: false, erro: 'Acesso negado' });
    }
    next();
  };
}

module.exports = { autenticar, exigirPapel };
