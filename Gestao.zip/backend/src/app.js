// =========================================================
// app.js — Configuração do Express
// =========================================================
require('dotenv').config();
const path = require('path');
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const rotas = require('./routes');
const { tratarErro } = require('./middlewares/error');

const app = express();

app.use(helmet());
app.use(express.json({ limit: '1mb' }));
app.use(cookieParser());

// Rate limit global (proteção básica)
const limiteGlobal = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 300,
  standardHeaders: true,
  legacyHeaders: false,
});
app.use(limiteGlobal);

// Serve o frontend (index.html, js/, pages/, css/, assets/) no mesmo domínio da API
app.use(express.static(path.join(__dirname, '..', '..', 'public')));

app.use('/api', rotas);

app.get('/health', (req, res) => res.json({ success: true, status: 'ok' }));

app.use(tratarErro);

module.exports = app;
