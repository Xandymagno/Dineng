// =========================================================
// services/historico.service.js — Histórico de status
// =========================================================
const historicoRepository = require('../repositories/historico.repository');

async function listar(idObra) {
  return historicoRepository.listar(idObra);
}

module.exports = { listar };
