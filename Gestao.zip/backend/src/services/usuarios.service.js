// =========================================================
// services/usuarios.service.js — Regras de usuários
// =========================================================
const bcrypt = require('bcryptjs');
const usuariosRepository = require('../repositories/usuarios.repository');

async function listar() {
  return usuariosRepository.listar();
}

async function criar(dados) {
  const existente = await usuariosRepository.buscarPorEmail(dados.email);
  if (existente) {
    const erro = new Error('E-mail já cadastrado');
    erro.status = 409;
    throw erro;
  }
  const senha_hash = dados.senha ? await bcrypt.hash(dados.senha, 10) : '';
  return usuariosRepository.criar({ ...dados, senha_hash });
}

async function atualizar(id, dados) {
  const usuario = await usuariosRepository.buscarPorId(id);
  if (!usuario) {
    const erro = new Error('Usuário não encontrado');
    erro.status = 404;
    throw erro;
  }
  const senha_hash = dados.senha
    ? await bcrypt.hash(dados.senha, 10)
    : usuario.senha_hash;
  return usuariosRepository.atualizar(id, { ...dados, senha_hash });
}

async function definirSituacao(id, { situacao }) {
  const usuario = await usuariosRepository.buscarPorId(id);
  if (!usuario) {
    const erro = new Error('Usuário não encontrado');
    erro.status = 404;
    throw erro;
  }
  return usuariosRepository.definirSituacao(id, situacao);
}

module.exports = { listar, criar, atualizar, definirSituacao };
