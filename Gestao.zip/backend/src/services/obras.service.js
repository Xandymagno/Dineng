// =========================================================
// services/obras.service.js — Regras de negócio de obras
// =========================================================
const obrasRepository = require('../repositories/obras.repository');
const historicoRepository = require('../repositories/historico.repository');

async function listar() {
  return obrasRepository.listar();
}

async function buscar(id) {
  const obra = await obrasRepository.buscarPorId(id);
  if (!obra) {
    const erro = new Error('Obra não encontrada');
    erro.status = 404;
    throw erro;
  }
  return obra;
}

async function criar(dados) {
  const cod = await obrasRepository.proximoCod();
  return obrasRepository.criar({
    ...dados,
    cod,
    cadastro: new Date().toISOString(),
    status: dados.status || 'CADASTRADA'
  });
}

async function atualizar(id, dados) {
  await buscar(id);
  return obrasRepository.atualizar(id, dados);
}

async function excluir(id) {
  await buscar(id);
  return obrasRepository.excluir(id);
}

async function avancarStatus(id, { novo_status, responsavel }) {
  const obra = await buscar(id);
  const statusAnterior = obra.status;
  await obrasRepository.atualizar(id, {
    status: novo_status,
    status_anterior: statusAnterior,
    data_novo_status: new Date().toISOString()
  });
  await historicoRepository.criar({
    id_obra: id,
    status_anterior: statusAnterior,
    novo_status,
    responsavel: responsavel || ''
  });
  return { status_anterior: statusAnterior, novo_status };
}

module.exports = { listar, buscar, criar, atualizar, excluir, avancarStatus };
