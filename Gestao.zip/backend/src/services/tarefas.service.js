// =========================================================
// services/tarefas.service.js — Regras de negócio de tarefas
// =========================================================
const tarefasRepository = require('../repositories/tarefas.repository');

async function listar() {
  return tarefasRepository.listar();
}

async function buscar(id) {
  const tarefa = await tarefasRepository.buscarPorId(id);
  if (!tarefa) {
    const erro = new Error('Tarefa não encontrada');
    erro.status = 404;
    throw erro;
  }
  return tarefa;
}

async function criar(dados) {
  return tarefasRepository.criar(dados);
}

async function atualizar(id, dados) {
  await buscar(id);
  return tarefasRepository.atualizar(id, dados);
}

async function excluir(id) {
  await buscar(id);
  return tarefasRepository.excluir(id);
}

module.exports = { listar, buscar, criar, atualizar, excluir };
