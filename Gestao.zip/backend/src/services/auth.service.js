// =========================================================
// services/auth.service.js — Regras de autenticação
// =========================================================
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const usuariosRepository = require('../repositories/usuarios.repository');

async function login({ email, senha }) {
  const usuario = await usuariosRepository.buscarPorEmail(email);
  if (!usuario || usuario.situacao !== 'ATIVO') {
    const erro = new Error('Usuário não encontrado ou inativo');
    erro.status = 401;
    throw erro;
  }
  // Sem senha cadastrada: bootstrap (senha vazia)
  if (!usuario.senha_hash) {
    if (senha !== '') {
      const erro = new Error('Senha incorreta');
      erro.status = 401;
      throw erro;
    }
  } else {
    const valida = await bcrypt.compare(senha, usuario.senha_hash);
    if (!valida) {
      const erro = new Error('Senha incorreta');
      erro.status = 401;
      throw erro;
    }
  }
  const token = jwt.sign(
    { id: usuario.id, nome: usuario.nome, email: usuario.email, papel: usuario.papel },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '8h' }
  );
  const { senha_hash, ...dadosPublicos } = usuario;
  // bootstrap = true quando o usuário ainda não definiu senha (primeiro acesso)
  return { token, usuario: { ...dadosPublicos, bootstrap: !senha_hash } };
}

async function definirSenha({ email, senha }) {
  const usuario = await usuariosRepository.buscarPorEmail(email);
  if (!usuario) {
    const erro = new Error('Usuário não encontrado');
    erro.status = 404;
    throw erro;
  }
  const hash = senha ? await bcrypt.hash(senha, 10) : '';
  await usuariosRepository.atualizarSenha(usuario.id, hash);
}

module.exports = { login, definirSenha };
