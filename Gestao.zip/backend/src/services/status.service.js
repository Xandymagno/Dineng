// =========================================================
// services/status.service.js — Listas de status
// =========================================================
const statusRepository = require('../repositories/status.repository');

async function geral() {
  return statusRepository.listarPorTipo('obra');
}

async function tarefas() {
  return statusRepository.listarPorTipo('tarefa');
}

async function financeiro() {
  return statusRepository.listarPorTipo('financeiro');
}

async function tiposProposta() {
  return statusRepository.listarPorTipo('tipo_proposta');
}

module.exports = { geral, tarefas, financeiro, tiposProposta };
