// =========================================================
// services/cronograma.service.js — Regras do cronograma
// =========================================================
const cronogramaRepository = require('../repositories/cronograma.repository');

async function listar() {
  return cronogramaRepository.listar();
}

async function salvar(dados) {
  // Se veio id, atualiza; senão cria
  if (dados.id) {
    return cronogramaRepository.atualizar(dados.id, dados);
  }
  return cronogramaRepository.criar(dados);
}

async function excluir(id) {
  return cronogramaRepository.excluir(id);
}

module.exports = { listar, salvar, excluir };
