// =========================================================
// services/relatorio.service.js — Relatório
// =========================================================
const relatorioRepository = require('../repositories/relatorio.repository');

async function listar() {
  return relatorioRepository.listar();
}

module.exports = { listar };
