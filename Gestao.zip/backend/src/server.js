// =========================================================
// server.js — Ponto de entrada do backend
// =========================================================
require('dotenv').config();
const app = require('./app');

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`API Gestão de Obras rodando em http://localhost:${PORT}`);
});
