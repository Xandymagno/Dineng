// =========================================================
// config/migrate.js — Aplica migrations versionadas
// =========================================================
const fs = require('fs');
const path = require('path');
const db = require('./db');

const dir = path.join(__dirname, '..', '..', 'migrations');
const arquivos = fs.readdirSync(dir).filter((f) => f.endsWith('.sql')).sort();

db.exec(`CREATE TABLE IF NOT EXISTS _migrations (
  nome TEXT PRIMARY KEY,
  aplicada_em TEXT DEFAULT (datetime('now'))
)`);

for (const arquivo of arquivos) {
  if (db.prepare('SELECT 1 FROM _migrations WHERE nome = ?').get(arquivo)) continue;
  db.exec(fs.readFileSync(path.join(dir, arquivo), 'utf8'));
  db.prepare('INSERT INTO _migrations (nome) VALUES (?)').run(arquivo);
  console.log('Migration aplicada:', arquivo);
}
console.log('Migrations em dia.');
