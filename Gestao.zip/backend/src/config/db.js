// =========================================================
// config/db.js — Conexão SQLite (embutido no Node 22+)
// Usa node:sqlite (DatabaseSync) — sem compilação nativa.
// =========================================================
const path = require('path');
const fs = require('fs');
const { DatabaseSync } = require('node:sqlite');

const dbPath = process.env.DB_PATH || path.join(__dirname, '..', '..', 'data', 'gerenciamento.db');

// Garante que a pasta existe (o SQLite não cria diretórios)
const dir = path.dirname(dbPath);
if (!fs.existsSync(dir)) {
  fs.mkdirSync(dir, { recursive: true });
}

const db = new DatabaseSync(dbPath);

db.exec('PRAGMA journal_mode = WAL');
db.exec('PRAGMA foreign_keys = ON');

// node:sqlite exige que as chaves de parâmetros nomeados tenham o prefixo
// (@id, :id, $id). O better-sqlite3 aceitava sem prefixo. Para manter os
// repositórios inalterados, normalizamos as chaves automaticamente.
function normalizarParams(params) {
  if (!params || typeof params !== 'object' || Array.isArray(params)) return params;
  const out = {};
  for (const [chave, valor] of Object.entries(params)) {
    out[/^[@:$]/.test(chave) ? chave : `@${chave}`] = valor;
  }
  return out;
}

const prepareOriginal = db.prepare.bind(db);
db.prepare = (sql) => {
  const stmt = prepareOriginal(sql);
  for (const metodo of ['run', 'get', 'all']) {
    const original = stmt[metodo].bind(stmt);
    stmt[metodo] = (...args) => {
      if (args.length && typeof args[0] === 'object' && !Array.isArray(args[0])) {
        args[0] = normalizarParams(args[0]);
      }
      return original(...args);
    };
  }
  return stmt;
};

module.exports = db;
